<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'borclaia_wp725' );

/** Database username */
define( 'DB_USER', 'borclaia_wp725' );

/** Database password */
define( 'DB_PASSWORD', 'pj)2SE8!F.hf)(54' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'riun6w4mcve0gk3ovudedftmohcbgsntt0iisaowqrfetsykrnt6hbxz7arqaipg' );
define( 'SECURE_AUTH_KEY',  '9g6oyp9di4jnkovd6pobx73n7hhfygzfpalceyzhdqysmmufqnqx3t2ve2lchss1' );
define( 'LOGGED_IN_KEY',    'pd6e1hlq0lfhrjlnqyzy6dvokvu0u7xqnagrirqeis8iznp9lrazg4sdgvsoamci' );
define( 'NONCE_KEY',        'c6wxe1bpm9jp8uv35raalo00qcasttdbyermxwdkizqc62cc50ksdnu9r39yyxkq' );
define( 'AUTH_SALT',        'xpzthieo7zwlmlvzu2xg3qhfvbceolyhgfb6xowsn3ymzlu5zrnc6wkvealnebck' );
define( 'SECURE_AUTH_SALT', '5dn7t34gg9vsthjslwwyk7yuvyscds159ajtqft5wdibkwrdtwmkl8wd4jykucmr' );
define( 'LOGGED_IN_SALT',   'r8cv97supbmjhn3oehflgbczvdvl0wkmfopyved4mujrltf6saubhy4xfbtrmuc6' );
define( 'NONCE_SALT',       'janjspdeqgxbaunzvgmoedlg2ckjbxjrfrid2fazwcgcipexe0omoypctma4wzqo' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wprw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
