<?php
Redux::set_section( $opt_name, array(
    'title' => esc_html__( 'Typography','kivicare' ),
    'id'    => 'default-style-section',
    'icon'  => 'el el-text-width',
    'desc'  => esc_html__('This section contains typography related options.','kivicare'),
    'fields'=> array(

    	array(
                'id'        => 'kivi_change_font',
                'type'      => 'switch',
                'title'     => esc_html__( 'Do you want to change fonts?','kivicare' ),
                'default'   => esc_html__( '0','kivicare' ),
                'on'    	=> esc_html__( 'Yes','kivicare' ),
                'off'   	=> esc_html__( 'No','kivicare' )
        ),

    	array(
                'id'        => 'body_font',
                'type'      => 'typography',
                'title'     => esc_html__( 'Body Font','kivicare' ),
                'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
                'required'  => array( 'kivi_change_font', '=', '1' ),
                'google'    => true,
                'font-style'    => true,
                'font-backup'   => true,
                'font-weight'   => true,
                'font-size'     => true,
                'line-height'   => false,
                'color'         => false,
                'text-align'    => false,
                'default'       => array(
                    'font-family' => esc_html__( 'Poppins','kivicare' ),
                    'google'      => true
                )
        ),

        array(
            'id'        => 'h1_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H1 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),

        array(
            'id'        => 'h2_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H2 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),

        array(
            'id'        => 'h3_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H3 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),
        array(
            'id'        => 'h4_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H4 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),
        array(
            'id'        => 'h5_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H5 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),
        array(
            'id'        => 'h6_font',
            'type'      => 'typography',
            'title'     => esc_html__( 'H6 Font','kivicare' ),
            'subtitle'  => esc_html__( 'Select the font.','kivicare' ),
            'required'  => array( 'kivi_change_font', '=', '1' ),
            'google'    => true,
            'font-style'    => true,
            'font-weight'   => true,
            'font-size'     => true,
            'line-height'   => false,
            'color'         => false,
            'text-align'    => false,
            'default'       => array(
                'font-family' => esc_html__( 'PT+Sans','kivicare' ),
                'google'      => true
            )
        ),
    )
));
