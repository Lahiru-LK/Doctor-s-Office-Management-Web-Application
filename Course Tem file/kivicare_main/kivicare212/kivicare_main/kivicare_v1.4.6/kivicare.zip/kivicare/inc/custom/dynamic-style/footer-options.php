<?php 
if(function_exists('get_field') && class_exists('ReduxFramework')) {
    add_action( 'wp_head', 'kivicare_footer_dynamic_style' );
}

function kivicare_footer_dynamic_style() {

    $page_id = get_queried_object_id();
    $kivi_option = get_option('kivi_options');
    $dynamic_css = array();

	if(get_field('acf_key_footer_switch' , $page_id) != 'default') {
		if(get_field('acf_key_footer_switch') == 'no')
		{
			$dynamic_css[] = array(
			'elements'  =>  '.footer-top',
			'property'  =>  'display',
			'value'     =>  'none !important'
			);
			
		}
	} else if(isset($kivi_option['kivi_footer_top'])) {
			
		if($kivi_option['kivi_footer_top'] == 'no')
		{
			$dynamic_css[] = array(
			'elements'  =>  '.footer-top',
			'property'  =>  'display',
			'value'     =>  'none !important'
			);

			
		}
	}
	
    if ( count( $dynamic_css ) > 0 )  {
        echo "<style type='text/css' id='kivicare-dynamic-css".rand(10,100000)."'>\n\n"; 
            kivicare_dynamic_style( $dynamic_css );
        echo '</style>';
    }  
}
