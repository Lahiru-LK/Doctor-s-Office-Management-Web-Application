<?php
function kivicare_display_header()
{
    $kivi_option = get_option('kivi_options');
    if (!is_front_page()) {

        if (((is_page() && !kivicare_is_frontpage())) && has_post_thumbnail(get_queried_object_id())) {
            $options = '';

            if(isset($kivi_option['bg_opacity'])) {
                $options = $kivi_option['bg_opacity'];
            }
           
            if ($options == "1")
            {
                $bg_class = esc_html__('iq-bg-over black', 'kivicare');
            }
            elseif ($options == "2")
            {
                $bg_class = esc_html__('iq-bg-over iq-over-dark-80', 'kivicare');
            }
            elseif ($options == "3")
            {
                $bg_class = esc_html__('breadcrumb-bg breadcrumb-ui', 'kivicare');
            }
            else
            {
                $bg_class = esc_html__('iq-bg-over iq-over-dark-80', 'kivicare');
            } ?>
            <div class="text-left iq-breadcrumb-one <?php if(!empty($bg_class)){ echo esc_attr($bg_class); } ?>"> <?php

        } else {

            if (!empty($kivi_option['bg_type']) && $kivi_option['bg_type'] == "1" ) {

                $bg_color = esc_html__('iq-bg-over black', 'kivicare');

            } elseif (!empty($kivi_option['bg_type']) && $kivi_option['bg_type'] == "2" ) {

                if (isset($kivi_option['banner_image']['url'])) {
                    $bgurl = $kivi_option['banner_image']['url'];
                }

                $options = $kivi_option['bg_opacity'];

                if ($options == "1") {
                } elseif ($options == "2") {
                    $bg_class = esc_html__('iq-bg-over iq-over-dark-80', 'kivicare');
                } elseif ($options == "3") {
                    $bg_class = esc_html__('breadcrumb-bg breadcrumb-ui', 'kivicare');
                } else {
                    $bg_class = esc_html__('iq-bg-over iq-over-dark-80', 'kivicare');

                }

            } else {
                $bg_class = esc_html__('iq-bg-over', 'kivicare');
            } ?>

                <div class="iq-breadcrumb-one <?php if ( isset($kivi_option['bg_type']) && !empty($kivi_option['bg_type'] == "1")) {
                        echo esc_attr($bg_color);
                    } ?> <?php if (!empty($bg_class))
                    {
                        echo esc_attr($bg_class);
                    } ?>" <?php if (!empty($bgurl)) { ?> style="background-image: url(<?php echo esc_url($bgurl); ?> );" <?php } ?>> <?php
        } ?> 

	    <div class="container"> <?php

            $options = '';
            
            if(!empty($kivi_option['bg_image'])) {
                $options = $kivi_option['bg_image'];
            }    

            if ($options == '1' && class_exists( 'ReduxFramework' ) ) {    ?>

                <div class="row align-items-center">
                    <div class="col-sm-12">
                        <nav aria-label="breadcrumb" class="text-center iq-breadcrumb-two">
                        <?php
                            echo kivicare_breadcrumbs_title_path();
                            if (isset($kivi_option['display_breadcrumbs']))
                            {
                                $options = $kivi_option['display_breadcrumbs'];
                                if ($options == "yes")
                                {
                        ?>
                                    <ol class="breadcrumb main-bg">
                                        <?php echo kivicare_custom_breadcrumbs(); ?>
                                    </ol>
                        <?php 
                                }
                            }
                        ?>
                        </nav>
                    </div>
                </div> <?php

            } elseif ($options == '2' && class_exists( 'ReduxFramework' ) ) { ?>

                <div class="row align-items-center">
                    <div class="col-lg-8 col-md-8 text-left align-self-center">
                        <nav aria-label="breadcrumb" class="text-left"> <?php
                            echo kivicare_breadcrumbs_title_path();
                            if (isset($kivi_option['display_breadcrumbs'])) {
                                $options = $kivi_option['display_breadcrumbs'];
                                if ($options == "yes") { ?>
                                    <ol class="breadcrumb main-bg">
                                        <?php echo kivicare_custom_breadcrumbs(); ?>
                                    </ol> <?php 
                                }
                            } ?>
                        </nav>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 text-right wow fadeInRight">
                        <?php echo kivicare_breadcrumbs_feature_image(); ?>
                    </div>
                </div> <?php 

            } elseif ($options == '3' && class_exists( 'ReduxFramework' ) ) { ?>

                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft">
                            <?php echo kivicare_breadcrumbs_feature_image(); ?>
                        </div>
                        <div class="col-lg-8 col-md-8 text-left align-self-center">
                            <nav aria-label="breadcrumb" class="text-right iq-breadcrumb-two"> <?php 
                                echo kivicare_breadcrumbs_title_path();
                                if (isset($kivi_option['display_breadcrumbs'])) {
                                    $options = $kivi_option['display_breadcrumbs'];
                                    if ($options == "yes") { ?>
                                        <ol class="breadcrumb main-bg">
                                            <?php echo kivicare_custom_breadcrumbs(); ?>
                                        </ol> <?php 
                                    }
                                } ?>
                            </nav>
                        </div>
                    </div> <?php

            } elseif ($options == '4' && class_exists( 'ReduxFramework' ) ) { ?>

                <div class="row align-items-center iq-breadcrumb-three">
                    <div class="col-sm-6 mb-3 mb-lg-0 mb-md-0">
                        <?php echo kivicare_breadcrumbs_title_path(); ?>
                    </div>
                    <div class="col-sm-6 ext-lg-right text-md-right text-sm-left">
                        <nav aria-label="breadcrumb" class="iq-breadcrumb-two"> <?php
                            if (isset($kivi_option['display_breadcrumbs'])) {
                                $options = $kivi_option['display_breadcrumbs'];
                                if ($options == "yes") { ?>
                                    <ol class="breadcrumb main-bg">
                                        <?php echo kivicare_custom_breadcrumbs(); ?>
                                    </ol> <?php
                                }
                            } ?>
                        </nav>
                    </div>
                </div> <?php
                
            } elseif ($options == '5' && class_exists( 'ReduxFramework' ) ) { ?>

                <div class="row align-items-center iq-breadcrumb-three">
                    <div class="col-sm-6 mb-3 mb-lg-0 mb-md-0">
                        <nav aria-label="breadcrumb" class="text-left iq-breadcrumb-two">
                            <?php 
                                if (isset($kivi_option['display_breadcrumbs']))
                                {
                                    $options = $kivi_option['display_breadcrumbs'];
                                    if ($options == "yes")
                                    {
                            ?>
                                        <ol class="breadcrumb main-bg">
                                            <?php echo kivicare_custom_breadcrumbs(); ?>
                                        </ol>
                            <?php 
                                    }
                                }
                            ?>
                        </nav>
                    </div>
                    <div class="col-sm-6 text-right">
                        <?php echo kivicare_breadcrumbs_title_path(); ?>
                    </div>
                </div> <?php

            } else  { ?>

                <div class="row align-items-center">
                    <div class="col-sm-12">
                        <nav aria-label="breadcrumb" class="text-center"> <?php 
                            echo kivicare_breadcrumbs_title_path(); ?>
                                <ol class="breadcrumb main-bg">
                                    <?php echo kivicare_custom_breadcrumbs(); ?>
                                </ol>
                        </nav>
                    </div>
                </div> <?php
                
            } ?>

  </div>
</div>
<?php
    }
}
