<?php
if(!class_exists('ReduxFramework'))
{
    return;
}

add_action( 'wp_head', 'kivicare_header_background_style' );
add_action( 'wp_enqueue_scripts', 'kivicare_menu_color_options' , 20);
add_action( 'wp_enqueue_scripts', 'kivicare_sub_menu_color_options' , 20);
add_action( 'wp_enqueue_scripts', 'kivicare_responsive_menu_color_options' , 20);
add_action( 'wp_enqueue_scripts', 'kivicare_action_btn_color_options' , 20);

function kivicare_header_background_style()
{
    $kivi_option = get_option('kivi_options');
    $dynamic_css = array();

    if(isset($kivi_option['kivi_header_variation']))
    {
        if(isset($kivi_option['kivi_header_background_type']) && $kivi_option['kivi_header_background_type'] != 'default')
        {
            $type = $kivi_option['kivi_header_background_type'];
            if($type == 'color')
            {
                if(!empty($kivi_option['kivi_header_background_color']))
                {
                    $dynamic_css[] = array(
                    'elements'  =>  'header#main-header',
                    'property'  =>  'background',
                    'value'     =>  ''.$kivi_option['kivi_header_background_color'].' !important'
                    );
                }
    
            }
    
            if($type == 'image')
            {
                if(!empty($kivi_option['kivi_header_background_image']['url']))
                {
                    $dynamic_css[] = array(
                    'elements'  =>  'header#main-header',
                    'property'  =>  'background',
                    'value'     =>  'url('.$kivi_option['kivi_header_background_image']['url'].') !important'
                    );
                }
    
            }
    
            if($type == 'transparent')
            {
    
                $dynamic_css[] = array(
                'elements'  =>  'header#main-header',
                'property'  =>  'background',
                'value'     =>  'transparent !important'
                );
    
            }
    
        }
    }else{}
    if ( count( $dynamic_css ) > 0 )
    {
        echo "<style type='text/css' id='kivicare-dynamic-css".rand(10,100000)."'>\n\n";
            kivicare_dynamic_style( $dynamic_css );
        echo '</style>';
    }  

}

function kivicare_menu_color_options()
{
    $kivi_option = get_option('kivi_options');
    $inline_css = '';
    
    if(isset($kivi_option['kivi_header_variation']) )
    {
        if(isset($kivi_option['header_menu_color_type']) && $kivi_option['header_menu_color_type'] == 'custom')
        {
    
            if(isset($kivi_option['kivi_header_menu_color']) && !empty($kivi_option['kivi_header_menu_color']))
            {
                $inline_css .= 'header .navbar ul li a,header .navbar ul li i{
                    color : '.$kivi_option['kivi_header_menu_color'].'!important;
                }';
            }
    
            if(isset($kivi_option['kivi_header_menu_active_color']) && !empty($kivi_option['kivi_header_menu_active_color']))
            {
                $inline_css .= ' header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent > a, header .navbar ul li.current-menu-parent i, header .navbar ul li.current-menu-item i, header .navbar ul li.current-menu-ancestor> a, header .navbar ul li.current-menu-ancestor> i{
                    color : '.$kivi_option['kivi_header_menu_active_color'].' !important;
                }';
            }
    
            if(isset($kivi_option['kivi_header_menu_hover_color']) && !empty($kivi_option['kivi_header_menu_hover_color']))
            {
                $inline_css .= 'header .navbar ul li:hover > a,header .navbar ul li:hover > i{
                    color : '.$kivi_option['kivi_header_menu_hover_color'].' !important;
                }';
                
            }  
        }
    }
    if(!empty($inline_css))
    {
        wp_add_inline_style('kivicare-style', $inline_css);
    }
    
}
function kivicare_sub_menu_color_options()
{
    $kivi_option = get_option('kivi_options');
    $inline_css = '';
    
    if(isset($kivi_option['kivi_header_variation']))
    {
        if(isset($kivi_option['header_submenu_color_type']) && $kivi_option['header_submenu_color_type'] == 'custom')
        {
           if(isset($kivi_option['kivi_header_submenu_color']) && !empty($kivi_option['kivi_header_submenu_color']))
           {
               $inline_css .= 'header .navbar ul li .sub-menu li a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li a, header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li i,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu  li i, header .navbar ul li .sub-menu li:hover .sub-menu li i,header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li i{
                   color : '.$kivi_option['kivi_header_submenu_color'].' !important;
               }';
           }
   
           if(isset($kivi_option['kivi_header_submenu_active_color']) && !empty($kivi_option['kivi_header_submenu_active_color']))
           {
                $inline_css .= 'header .navbar ul li .sub-menu li.current-menu-item a,header .navbar ul li .sub-menu li.current-menu-item i,header .navbar ul li .sub-menu li.current-menu-ancestor a,header .navbar ul li .sub-menu li.current-menu-ancestor i,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  i
                   {
                       color : '.$kivi_option['kivi_header_submenu_active_color'].' !important;
                   }';

                $inline_css .= 'header .navbar ul li .sub-menu li a:hover:before, header .navbar ul li .sub-menu li.current-menu-item a:before, header .main-header .navbar ul li .sub-menu li:hover>a:before, header .main-header .navbar ul li .sub-menu li.current-menu-parent a:before, header .main-header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item a:before
                {
                    background : '.$kivi_option['kivi_header_submenu_active_color'].' !important;
                }';
           }
   
           if(isset($kivi_option['kivi_header_submenu_hover_color']) && !empty($kivi_option['kivi_header_submenu_hover_color']))
           {
               $inline_css .= 'header .navbar ul li .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover i,header .navbar ul li .sub-menu li.current-menu-parent:hover a, header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a, header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover i, header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover i, header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover i,header .navbar ul li .sub-menu li:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover .sub-menu li:hover i{
                   color : '.$kivi_option['kivi_header_submenu_hover_color'].' !important;
               }';

               $inline_css .= 'header .navbar ul li .sub-menu li a:hover:before, header .main-header .navbar ul li .sub-menu li:hover>a:before, header .main-header .navbar ul li .sub-menu li.current-menu-parent a:before, header .main-header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item a:before
                {
                    background : '.$kivi_option['kivi_header_submenu_hover_color'].' !important;
                }';
           }
   
           if(isset($kivi_option['kivi_header_submenu_background_color']) && !empty($kivi_option['kivi_header_submenu_background_color']))
           {
               $inline_css .= 'header .navbar ul li .sub-menu li a,header .navbar ul li .sub-menu li.current-menu-parent li a,header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li a,header .navbar ul li .sub-menu li:hover .sub-menu li a {
                   background : '.$kivi_option['kivi_header_submenu_background_color'].' !important;
               }';
           }
   
           if(isset($kivi_option['header_submenu_background_hover_color']) && !empty($kivi_option['header_submenu_background_hover_color']))
           {
               $inline_css .= 'header .navbar ul li .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li:hover a,header .navbar ul li .sub-menu li.current-menu-parent:hover .sub-menu li:hover a,header .navbar ul li .sub-menu li:hover .sub-menu li:hover a{
                   background : '.$kivi_option['header_submenu_background_hover_color'].' !important;
               }';
           }
   
           if(isset($kivi_option['header_submenu_background_active_color']) && !empty($kivi_option['header_submenu_background_active_color']))
           {
               $inline_css .= 'header .navbar ul li .sub-menu li.current-menu-item a,header .navbar ul li .sub-menu li.current-menu-parent a,header .navbar ul li .sub-menu li.current-menu-parent .sub-menu li.current-menu-item  a {
                   background : '.$kivi_option['header_submenu_background_active_color'].' !important;
               }';
           }
       }
    }   
    if(!empty($inline_css))
    {
        wp_add_inline_style('kivicare-style', $inline_css);
    }
}

function kivicare_responsive_menu_color_options()
{
    $kivi_option = get_option('kivi_options');
    $inline_css = '';
    
    if(isset($kivi_option['responsive_menu_button_type']) && $kivi_option['responsive_menu_button_type'] == 'custom')
    {
        if(isset($kivi_option['responsive_menu_button_color']) && !empty($kivi_option['responsive_menu_button_color']))
        {
            $inline_css .= 'header .navbar-light .navbar-toggler{
                background : '.$kivi_option['responsive_menu_button_color'].' !important;
                border-color : '.$kivi_option['responsive_menu_button_color'].' !important;
            }';
        }

        if(isset($kivi_option['responsive_menu_button_background_color']) && !empty($kivi_option['responsive_menu_button_background_color']))
        {
            $inline_css .= 'header .navbar-light .navbar-toggler{
                background : '.$kivi_option['responsive_menu_button_background_color'].' !important;
                border-color : '.$kivi_option['responsive_menu_button_background_color'].' !important;
            }';
        }
        if(isset($kivi_option['responsive_menu_color']) && !empty($kivi_option['responsive_menu_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li a{
                    color : '.$kivi_option['responsive_menu_color'].' !important;
                }
            }';
        }
        if(isset($kivi_option['responsive_menu_color']) && !empty($kivi_option['responsive_menu_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li a, header .navbar ul li i{
                    color : '.$kivi_option['responsive_menu_color'].' !important;
                }
            }';
        }

         if(isset($kivi_option['responsive_menu_hover_color']) && !empty($kivi_option['responsive_menu_hover_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li:hover a,header .navbar ul li:hover i{
                    color : '.$kivi_option['responsive_menu_hover_color'].' !important;
                }
            }';
        }
        if(isset($kivi_option['responsive_menu_hover_color']) && !empty($kivi_option['responsive_menu_hover_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li:hover a,header .navbar ul li:hover i,header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent a, header .navbar ul li.current-menu-parent i, header .navbar ul li.current-menu-item i,header .navbar ul li.current-menu-ancestor a,header .navbar ul li.current-menu-ancestor i{
                    color : '.$kivi_option['responsive_menu_hover_color'].' !important;
                }
            }';
        }

        if(isset($kivi_option['responsive_menu_background_color']) && !empty($kivi_option['responsive_menu_background_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li a,header .iq-mobile-main{
                    background : '.$kivi_option['responsive_menu_background_color'].' !important;
                }
            }';
        }
        if(isset($kivi_option['responsive_menu_active_background_color']) && !empty($kivi_option['responsive_menu_active_background_color']))
        {
            $inline_css .= '@media (max-width: 992px){
                header .navbar ul li.current-menu-item a, header .navbar ul li a:hover,
                header .navbar ul li:hover a,header .navbar ul li.current-menu-item a, header .navbar ul li.current-menu-parent a,   header .navbar ul li.current-menu-ancestor a{
                    background : '.$kivi_option['responsive_menu_active_background_color'].' !important;
                }
            }';
        }

    }
    if(!empty($inline_css))
    {
        wp_add_inline_style('kivicare-style', $inline_css);
    }
}

function kivicare_action_btn_color_options()
{
    $kivi_option = get_option('kivi_options');
    $inline_css = '';

    if(isset($kivi_option['header_display_button'])) {
        $options = $kivi_option['header_display_button'];
        if($options == "no")
        {
            $inline_css .= '
            .sub-main .iq-button-style-2,
            .iq-mobile-main .iq-button-style-2 {
            display : none !important;
            }';
        }
    }

    if(isset($kivi_option['header_display_btn2'])) {
        $options = $kivi_option['header_display_btn2'];
        if($options == "no")
        {
            $inline_css .= '
            .sub-main .iq-button-style-1,
            .iq-mobile-main .iq-button-style-1 {
                display : none !important;
            }';
        }
    }
    
    if(isset($kivi_option['header_button_color_type']) && $kivi_option['header_button_color_type'] == 'custom')
    {    
        if(isset($kivi_option['kivi_download_btn_background']) && !empty($kivi_option['kivi_download_btn_background']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-2 span.iq-btn-text-holder, 
            header .sub-main .iq-button-style-2 .iq-btn-icon-holder::after,
            .iq-mobile-main .iq-button-style-2 span.iq-btn-text-holder, 
            .iq-mobile-main .iq-button-style-2 .iq-btn-icon-holder::after {
                background : '.$kivi_option['kivi_download_btn_background'].' !important;
            }';
        }

        if(isset($kivi_option['kivi_download_btn_background_hover']) && !empty($kivi_option['kivi_download_btn_background_hover']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-2:hover span.iq-btn-text-holder, 
            header .sub-main .iq-button-style-2:hover .iq-btn-icon-holder::after,
            .iq-mobile-main .iq-button-style-2:hover span.iq-btn-text-holder, 
            .iq-mobile-main .iq-button-style-2:hover .iq-btn-icon-holder::after {
                background : '.$kivi_option['kivi_download_btn_background_hover'].' !important;
            }';
        }
       
        if(isset($kivi_option['kivi_download_btn_text']) && !empty($kivi_option['kivi_download_btn_text']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-2 span, 
            header .sub-main .iq-button-style-2 span i,
            .iq-mobile-main .iq-button-style-2 span, 
            .iq-mobile-main .iq-button-style-2 span i {
                color : '.$kivi_option['kivi_download_btn_text'].' !important;
            }';
        }

        if(isset($kivi_option['kivi_download_btn_text_hover']) && !empty($kivi_option['kivi_download_btn_text_hover']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-2:hover span, 
            header .sub-main .iq-button-style-2:hover span i,
            .iq-mobile-main .iq-button-style-2:hover span, 
            .iq-mobile-main .iq-button-style-2:hover span i {
                color : '.$kivi_option['kivi_download_btn_text_hover'].' !important;
            }';
        }
        
    }
    
    if(isset($kivi_option['header_btn2_color_type']) && $kivi_option['header_btn2_color_type'] == 'custom')
    {    
        
        if(isset($kivi_option['kivi_btn2_background']) && !empty($kivi_option['kivi_btn2_background']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-1 span.iq-btn-text-holder, 
            header .sub-main .iq-button-style-1 .iq-btn-icon-holder::after, 
            .iq-mobile-main .iq-button-style-1 span.iq-btn-text-holder, 
            .iq-mobile-main .iq-button-style-1 .iq-btn-icon-holder::after {
                background : '.$kivi_option['kivi_btn2_background'].' !important;
            }';
        }

        if(isset($kivi_option['kivi_btn2_background_hover']) && !empty($kivi_option['kivi_btn2_background_hover']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-1:hover span.iq-btn-text-holder, 
            header .sub-main .iq-button-style-1:hover .iq-btn-icon-holder::after,
            .iq-mobile-main .iq-button-style-1:hover span.iq-btn-text-holder, 
            .iq-mobile-main .iq-button-style-1:hover .iq-btn-icon-holder::after {
                background : '.$kivi_option['kivi_btn2_background_hover'].' !important;
            }';
        }
       
        if(isset($kivi_option['kivi_btn2_text']) && !empty($kivi_option['kivi_btn2_text']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-1 span, 
            header .sub-main .iq-button-style-1 span i,
            .iq-mobile-main .iq-button-style-1 span, 
            .iq-mobile-main .iq-button-style-1 span i {
                color : '.$kivi_option['kivi_btn2_text'].' !important;
            }';
        }

        if(isset($kivi_option['kivi_btn2_text_hover']) && !empty($kivi_option['kivi_btn2_text_hover']))
        {
            $inline_css .= '
            header .sub-main .iq-button-style-1:hover span, 
            header .sub-main .iq-button-style-1:hover span i,
            .iq-mobile-main .iq-button-style-1:hover span, 
            .iq-mobile-main .iq-button-style-1:hover span i {
                color : '.$kivi_option['kivi_btn2_text_hover'].' !important;
            }';
        }
        
    }


    if(!empty($inline_css))
    {
        wp_add_inline_style('kivicare-style', $inline_css);
    }
}
