<?php
if(!function_exists('get_field') && !class_exists('ReduxFramework')){
    return;
}
add_action( 'wp_head', 'kivicare_banner_dynamic_style' );
function kivicare_banner_dynamic_style() {
    $page_id = get_queried_object_id();
    $kivi_option = get_option('kivi_options');
    $dynamic_css = array();

        if(get_field('field_QnF1', $page_id) != 'default') {
            if(get_field('field_QnF1' , $page_id) == 'no') {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
                 $dynamic_css[] = array(
                'elements'  =>  '.content-area .site-main',
                'property'  =>  'padding',
                'value'     =>  '0 !important'
                );
            }
        }
        else if(isset($kivi_option['display_banner']))
        {
             
            if($kivi_option['display_banner'] == 'no')
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );

                $dynamic_css[] = array(
                'elements'  =>  '.content-area .site-main',
                'property'  =>  'padding',
                'value'     =>  '0 !important'
                );
            }
        }
    
    
    
        $key = get_field('key_pjros' , $page_id);
        if(isset($key['display_title']) && $key['display_title'] != 'default'  && $key['display_title'] == 'no' )
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .title',
            'property'  =>  'display',
            'value'     =>  'none !important'
            );
        }
        else if(isset($kivi_option['display_title']))
        {
         
            if($kivi_option['display_title'] == 'no')
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one .title',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
            }
        }
    
    
        $key = get_field('key_pjros' , $page_id);
        if(isset($key['display_breadcumb']) && $key['display_breadcumb'] != 'default'  && $key['display_breadcumb'] == 'no' )
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .breadcrumb',
            'property'  =>  'display',
            'value'     =>  'none !important'
            );
        }
        else if(isset($kivi_option['display_breadcumb']))
        {
         
            if($kivi_option['display_breadcumb'] == 'no')
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one .breadcrumb',
                'property'  =>  'display',
                'value'     =>  'none !important'
                );
            }
        }
    
    if(isset($kivi_option['bg_title_color']))
    {
         
        if($kivi_option['bg_title_color'] == 'no')
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one .title',
            'property'  =>  'color',
            'value'     =>  $kivi_option['bg_title_color'].'!important'
            );
        }
    }

    $key = get_field('key_banner_back' , $page_id);

    if(isset($key['banner_background_type']) && $key['banner_background_type'] != 'default')
    {
        if($key['banner_background_type'] == 'color')
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one',
            'property'  =>  'background',
            'value'     =>  $key['banner_background_color']. ' !important'
            );
        }

        if($key['banner_background_type'] == 'image')
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-breadcrumb-one',
            'property'  =>  'background-image',
            'value'     =>  'url('.$key['banner_background_image']['url'].') !important'
            );

            if(!empty($key['banner_background_size']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background-size',
                'value'     =>  $key['banner_background_size']. ' !important'
                ); 
            }

            if(!empty($key['banner_background_repeat']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background-repeat',
                'value'     =>  $key['banner_background_repeat']. ' !important'
                ); 
            }
        }
    }
    else if(isset($kivi_option['bg_type']))
    {    
        $opt = $kivi_option['bg_type'];
        if($opt == '1')
        {
            if(isset($kivi_option['bg_color']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background',
                'value'     =>  $kivi_option['bg_color']. ' !important'
                );
            }
            
        }
        if($opt == '2')
        {
            if(isset($kivi_option['banner_image']['url']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-breadcrumb-one',
                'property'  =>  'background-image',
                'value'     =>  'url('.$kivi_option['banner_image']['url'].') !important'
                );
            }
            
        }

        
    }
  
    if ( count( $dynamic_css ) > 0 ) 
    {
        echo "<style type='text/css' id='kivicare-dynamic-css".rand(10,100000)."'>\n\n"; 
            kivicare_dynamic_style( $dynamic_css );
        echo '</style>';
    }  
}

function kivicare_banner_class()
{
    $kivi_option = get_option('kivi_options');
    $classes = array();
    
    array_push($classes, ' iq-bg-over');    

    if(isset($kivi_option['bg_opacity']))
    {
        $opt = $kivi_option['bg_opacity'];
        if($opt == '1')
        {
            array_push($classes, ' black');         
        }
        if($opt == '2')
        {
            array_push($classes, ' iq-over-dark-80');           
        }
        if($opt == '3')
        {
            array_push($classes, ' breadcrumb-bg breadcrumb-ui');           
        }
    }

    echo esc_attr(implode(' ',$classes));
}
