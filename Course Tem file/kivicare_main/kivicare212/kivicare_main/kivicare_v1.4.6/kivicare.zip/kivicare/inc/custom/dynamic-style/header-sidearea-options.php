<?php
if(!class_exists('ReduxFramework'))
{
    return;
}
add_action( 'wp_head', 'kivicare_header_sidearea_dynamic_style' );
function kivicare_header_sidearea_dynamic_style()
{
    $kivi_option = get_option('kivi_options');    
    $dynamic_css = array();

    if(isset($kivi_option['header_display_side_area']) && $kivi_option['header_display_side_area'] == 'no')
    {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-sidearea-btn-container',
            'property'  =>  'display',
            'value'     =>  'none !important'
            );
        
    }
    if(isset($kivi_option['sidearea_background_type']) && $kivi_option['sidearea_background_type'] != 'default')
    {
        $type = $kivi_option['sidearea_background_type'];  
        if($type == 'color')
        {
            if(!empty($kivi_option['sidearea_background_color']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-menu-side-bar',
                'property'  =>  'background',
                'value'     =>  ''.$kivi_option['sidearea_background_color'].' !important'
                );  
            }
            
        }  

        if($type == 'image')
        {
            if(!empty($kivi_option['sidearea_background_image']['url']))
            {
                $dynamic_css[] = array(
                'elements'  =>  '.iq-menu-side-bar',
                'property'  =>  'background',
                'value'     =>  'url('.$kivi_option['sidearea_background_image']['url'].') !important'
                );  
            }
            
        }   

        if($type == 'transparent')
        {
            
                $dynamic_css[] = array(
                'elements'  =>  '.iq-menu-side-bar',
                'property'  =>  'background',
                'value'     =>  'transparent !important'
                );  
            
            
        }    
            
        
    }
    if(isset($kivi_option['sidearea_width']['width']) && !empty($kivi_option['sidearea_width']['width']) && strlen($kivi_option['sidearea_width']['width']) > 2)
    {
        $kivi_option['sidearea_width']['width'];
        $dynamic_css[] = array(
        'elements'  =>  '.iq-menu-side-bar',
        'property'  =>  'width',
        'value'     =>  ''.$kivi_option['sidearea_width']['width'].' !important'
        );

        $dynamic_css[] = array(
        'elements'  =>  '.iq-menu-side-bar',
        'property'  =>  'right',
        'value'     =>  '-'.$kivi_option['sidearea_width']['width'].' !important'
        ); 

        $dynamic_css[] = array(
        'elements'  =>  '.side-bar-open .iq-menu-side-bar',
        'property'  =>  'right',
        'value'     =>  '0 !important'
        );
    }
    if(isset($kivi_option['sidearea_btn_color_type']) && $kivi_option['sidearea_btn_color_type'] == 'custom')
    {
        if(isset($kivi_option['sidearea_btn_open_color']) && !empty($kivi_option['sidearea_btn_open_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-sidearea-btn-container',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_open_color'].' !important'
            );  
        }

        if(isset($kivi_option['sidearea_btn_open_hover']) && !empty($kivi_option['sidearea_btn_open_hover']))
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-sidearea-btn-container:hover',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_open_hover'].' !important'
            );  
        }
        if(isset($kivi_option['sidearea_btn_close_color']) && !empty($kivi_option['sidearea_btn_close_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  'body.side-bar-open .iq-sidearea-btn-container.btn-container-close',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_close_color'].' !important'
            );  
        }

        if(isset($kivi_option['sidearea_btn_close_hover']) && !empty($kivi_option['sidearea_btn_close_hover']))
        {
            $dynamic_css[] = array(
            'elements'  =>  'body.side-bar-open .iq-sidearea-btn-container.btn-container-close:hover',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_close_hover'].' !important'
            );  
        }

        if(isset($kivi_option['sidearea_btn_line_color']) && !empty($kivi_option['sidearea_btn_line_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  '.menu-btn .line',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_line_color'].' !important'
            );  
        }

         if(isset($kivi_option['sidearea_btn_line_hover_color']) && !empty($kivi_option['sidearea_btn_line_hover_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  '.iq-sidearea-btn-container:hover .menu-btn .line',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_line_hover_color'].' !important'
            );  
        }

         if(isset($kivi_option['sidearea_btn_close_line_color']) && !empty($kivi_option['sidearea_btn_close_line_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  'body.side-bar-open .iq-sidearea-btn-container.btn-container-close .menu-btn .line',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_close_line_color'].' !important'
            );  
        }

        if(isset($kivi_option['sidearea_btn_close_line_hover_color']) && !empty($kivi_option['sidearea_btn_close_line_hover_color']))
        {
            $dynamic_css[] = array(
            'elements'  =>  'body.side-bar-open .iq-sidearea-btn-container.btn-container-close:hover .menu-btn .line',
            'property'  =>  'background',
            'value'     =>  ''.$kivi_option['sidearea_btn_close_line_hover_color'].' !important'
            );  
        }
    }
    if ( count( $dynamic_css ) > 0 ) 
    {
        echo "<style type='text/css' id='kivicare-dynamic-css".rand(10,100000)."'>\n\n"; 
            kivicare_dynamic_style( $dynamic_css );
        echo '</style>';
    }  
}
