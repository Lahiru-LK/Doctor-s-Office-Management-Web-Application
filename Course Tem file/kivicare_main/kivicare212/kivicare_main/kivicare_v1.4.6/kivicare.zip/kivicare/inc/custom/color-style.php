<?php
if (function_exists('get_field') && class_exists('ReduxFramework')) {
    add_action('wp_enqueue_scripts', 'kivicare_color_options', 20);
}
function kivicare_color_options()
{
    $kivi_option = get_option('kivi_options');

    $kivi_color = get_field('key_color_pallete');


    $color_var = ':root { ';

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['primary_color'])) {
        $color = $kivi_color['primary_color'];
        $color_var .= ' --primary-color: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['primary_color'])) {
        $color = $kivi_option['primary_color'];
        $color_var .= ' --primary-color: ' . $color . ' !important;';
    }

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['secondary_color']) && !empty($kivi_color['secondary_color'])) {
        $color = $kivi_color['secondary_color'];
        $color_var .= ' --secondary-color: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['secondary_color'])) {
        $color = $kivi_option['secondary_color'];
        $color_var .= ' --secondary-color: ' . $color . ' !important;';
    }

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['text_color']) && !empty($kivi_color['text_color'])) {
        $color = $kivi_color['text_color'];
        $color_var .= ' --body-text: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['text_color'])) {
        $color = $kivi_option['text_color'];
        $color_var .= ' --body-text: ' . $color . ' !important;';
    }

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['title_color']) && !empty($kivi_color['title_color'])) {
        $color = $kivi_color['title_color'];
        $color_var .= ' --title-color: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['title_color'])) {
        $color = $kivi_option['title_color'];
        $color_var .= ' --title-color: ' . $color . ' !important;';
    }

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['sub_title_color']) && !empty($kivi_color['sub_title_color'])) {
        $color = $kivi_color['sub_title_color'];
        $color_var .= ' --sub-title-color: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['sub_title_color'])) {
        $color = $kivi_option['sub_title_color'];
        $color_var .= ' --sub-title-color: ' . $color . ' !important;';
    }

    if (get_field('key_color_switch') != 'default' && isset($kivi_color['white_color']) && !empty($kivi_color['white_color'])) {
        $color = $kivi_color['white_color'];
        $color_var .= '  --white-color: ' . $color . ' !important;';
    } elseif (!empty($kivi_option['white_color'])) {
        $color = $kivi_option['white_color'];
        $color_var .= '  --white-color: ' . $color . ' !important;';
    }


    $color_var .= '}';

    wp_add_inline_style('kivicare-style', $color_var);
}
function kivicare_banner_title_color()
{
    //Set Body Color
    $kivi_option = get_option('kivi_options');


    if (!empty($kivi_option['bg_title_color'])) {
        $bg_title_color = $kivi_option['bg_title_color'];
    }

    $bn_title_color = "";

    if (!empty($bg_title_color)) {
        $bn_title_color .= "
        .iq-breadcrumb-one h2{
            color: $bg_title_color !important;
        }";
    }
    wp_add_inline_style('kivicare-style', $bn_title_color);
}
add_action('wp_enqueue_scripts', 'kivicare_banner_title_color', 20);

function kivicare_layout_color()
{
    //Set Body Color
    $kivi_option = get_option('kivi_options');

    if (!empty($kivi_option['kivi_layout_color'])) {
        $kivi_layout_color = $kivi_option['kivi_layout_color'];
    }
    $body_accent_color = "";

    if (function_exists('get_field')) {
        $page_id_body_col = get_queried_object_id();
        $key_body_bg_col = get_field('key_body', $page_id_body_col);
        if (isset($key_body_bg_col['body_variation']) && $key_body_bg_col['body_variation'] == 'has_body_color') {
            if (isset($key_body_bg_col['acf_body_color']) && !empty($key_body_bg_col['acf_body_color'])) {
                $body_back_color = $key_body_bg_col['acf_body_color'];
            }
        }
    }

    if (isset($body_back_color) && !empty($body_back_color)) {
        $body_accent_color .= "
        body {
            background-color: $body_back_color !important;
        }";
    } else if (!empty($kivi_option['layout_set']) && $kivi_option['layout_set'] == "1" && $key_body_bg_col['body_variation'] != 'default') {
        if (!empty($kivi_layout_color) && $kivi_layout_color != '#ffffff') {
            $body_accent_color .= "
            body {
                background-color: $kivi_layout_color !important;
            }";
        }
    } else {
        $body_accent_color = "";
    }

    wp_add_inline_style('kivicare-style', $body_accent_color);
}
add_action('wp_enqueue_scripts', 'kivicare_layout_color', 20);

function kivicare_loader_color()
{
    //Set Loader Background Color
    $kivi_option = get_option('kivi_options');

    if (!empty($kivi_option['loader_color'])) {
        $loader_color = $kivi_option['loader_color'];
    }
    $ld_color = "";

    if (!empty($loader_color) && $loader_color != '#ffffff') {
        $ld_color .= "
        #loading {
            background : $loader_color !important;
        }";
    }
    wp_add_inline_style('kivicare-style', $ld_color);
}
add_action('wp_enqueue_scripts', 'kivicare_loader_color', 20);

function kivicare_bg_color()
{
    //Set Background Color
    $kivi_option = get_option('kivi_options');

    if (!empty($kivi_option['bg_color'])) {
        $bg_color = $kivi_option['bg_color'];
    }
    $background_color = "";

    if (!empty($kivi_option['bg_type']) && $kivi_option['bg_type'] == "1") {
        if (!empty($bg_color) && $bg_color != '#ffffff') {
            $background_color .= "
            .iq-bg-over {
                background : $bg_color !important;
            }";
        }
    }
    wp_add_inline_style('kivicare-style', $background_color);
}
add_action('wp_enqueue_scripts', 'kivicare_bg_color', 20);

function kivicare_opacity_color()
{
    //Set Background Opacity Color
    $kivi_option = get_option('kivi_options');

    if (!empty($kivi_option['bg_opacity']) && $kivi_option['bg_opacity'] == "3") {
        $bg_opacity = $kivi_option['opacity_color']['rgba'];
    }
    $op_color = "";

    if (!empty($kivi_option['bg_opacity']) && $kivi_option['bg_opacity'] == "3") {
        if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
            $op_color .= "
        .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
            background : $bg_opacity !important;
        }";
        }
    }
    wp_add_inline_style('kivicare-style', $op_color);
}
add_action('wp_enqueue_scripts', 'kivicare_opacity_color', 20);

function kivicare_header_radio()
{
    //Set Text Logo Color
    $kivi_option = get_option('kivi_options');

    if (!empty($kivi_option['header_color'])) {
        $logo = $kivi_option['header_color'];
    }
    $logo_color = "";

    if (!empty($kivi_option['header_radio']) && $kivi_option['header_radio'] == "1") {
        if (!empty($logo) && $logo != '#ffffff') {
            $logo_color .= "
            .logo-text {
                color : $logo !important;
            }";
        }
    }
    wp_add_inline_style('kivicare-style', $logo_color);
}
add_action('wp_enqueue_scripts', 'kivicare_header_radio', 20);

function kivicare_footer_color()
{

    //Set Footer Background Color
    $kivi_option = get_option('kivi_options');

    $footer_color = "";

    if (function_exists('get_field') && !empty(get_field('footer_background_color'))) {
        $f_back_color = get_field('footer_background_color');
        $footer_color .= "
        footer {  background : $f_back_color !important; }";
    } else if (isset($kivi_option['change_footer_color'])) {
        if ($kivi_option['change_footer_color'] == "0") {
            $f_color = $kivi_option['footer_color'];
            $footer_color .= "
            footer {
                background-color : $f_color !important;
            }";
        }
    } else {
        $footer_color = '';
    }

    wp_add_inline_style('kivicare-style', $footer_color);
}
add_action('wp_enqueue_scripts', 'kivicare_footer_color', 20);
