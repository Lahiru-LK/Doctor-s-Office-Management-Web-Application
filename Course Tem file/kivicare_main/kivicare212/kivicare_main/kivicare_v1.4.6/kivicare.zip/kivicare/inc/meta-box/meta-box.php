<?php
add_filter( 'rwmb_meta_boxes', 'kivicare_meta_boxes' );
function kivicare_meta_boxes( $meta_boxes ) {	

	// Team Member Details In Class
	$meta_boxes[] = array(
		'title'			=> esc_html__( 'Team Member Details','kivicare' ),
		'post_types'	=> 'team',
		'fields'		=> array(

			array(
				'id'		=> 'kivi_team_designation',
				'name'		=> esc_html__( 'Designation :','kivicare' ),				
				'type'		=> 'text'				
			),
					
			array(
				'id'		=> 'kivicare_team_facebook',
				'name'		=> esc_html__( 'Facebook Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_twitter',
				'name'		=> esc_html__( 'Twitter Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_google',
				'name'		=> esc_html__( 'Google Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_github',
				'name'		=> esc_html__( 'Github Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_insta',
				'name'		=> esc_html__( 'Instagram Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_linkedin',
				'name'		=> esc_html__( 'Linkedin Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_tumblr',
				'name'		=> esc_html__( 'Tumblr Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_pinterest',
				'name'		=> esc_html__( 'Pinterest Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_dribbble',
				'name'		=> esc_html__( 'Dribbble Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_reddit',
				'name'		=> esc_html__( 'Reddit Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_flickr',
				'name'		=> esc_html__( 'Flickr Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_skype',
				'name'		=> esc_html__( 'Skype Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_youtube_play',
				'name'		=> esc_html__( 'Youtube-play Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_vimeo',
				'name'		=> esc_html__( 'Vimeo Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_soundcloud',
				'name'		=> esc_html__( 'Soundcloud Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_wechat',
				'name'		=> esc_html__( 'Wechat Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_renren',
				'name'		=> esc_html__( 'Renren Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_weibo',
				'name'		=> esc_html__( 'Weibo Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_xing',
				'name'		=> esc_html__( 'Xing Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_qq',
				'name'		=> esc_html__( 'QQ Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_rss',
				'name'		=> esc_html__( 'RSS Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_vk',
				'name'		=> esc_html__( 'VK Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_behance',
				'name'		=> esc_html__( 'Behance Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_team_snapchat',
				'name'		=> esc_html__( 'Snapchat Url :','kivicare' ),				
				'type'		=> 'text'
			),
		),
	);

	

	// Testimonial Member Details In Class
	$meta_boxes[] = array(
		'title'			=> esc_html__( 'Testimonial Member Details','kivicare' ),
		'post_types'	=> 'testimonial',
		'fields'		=> array(
					
			array(
				'id'		=> 'kivicare_testimonial_designation',
				'name'		=> esc_html__( 'Designation :','kivicare' ),				
				'type'		=> 'text'				
			),
		),
	);

	// Leader Member Details In Class
	$meta_boxes[] = array(
		'title'			=> esc_html__( 'Leader Member Details','kivicare' ),
		'post_types'	=> 'consultleadership',
		'fields'		=> array(
					
			array(
				'id'		=> 'kivicare_leader_designation',
				'name'		=> esc_html__( 'Designation :','kivicare' ),				
				'type'		=> 'text'				
			),
			array(
				'type'	=>'divider',
			),
			array(
				'id'		=> 'kivicare_leader_facebook',
				'name'		=> esc_html__( 'Facebook Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_leader_twitter',
				'name'		=> esc_html__( 'Twitter Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_leader_google',
				'name'		=> esc_html__( 'Google Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_leader_github',
				'name'		=> esc_html__( 'Github Url :','kivicare' ),				
				'type'		=> 'text'
			),
			array(
				'id'		=> 'kivicare_leader_insta',
				'name'		=> esc_html__( 'Instagram Url :','kivicare' ),				
				'type'		=> 'text'
			),

		),
	);

	// Faqs Details In Class
	$meta_boxes[] = array(
		'title'			=> esc_html__( 'Flipbox Details','kivicare' ),
		'post_types'	=> 'flipbox',
		'fields'		=> array(
					
			array(
				'id'		=> 'flipbox_button_name',
				'name'		=> esc_html__( 'Flipbox Button Name :','kivicare' ),				
				'type'		=> 'text'				
			),

			array(
				'id'		=> 'flipbox_button_link',
				'name'		=> esc_html__( 'Flipbox Button Link :','kivicare' ),				
				'type'		=> 'text'				
			),

			array(
				'id'		=> 'hover_image',
				'name'		=> esc_attr__( 'Hover Image :','kivicare' ),				
				'type'		=> 'image_advanced',
				'max_file_uploads' => 1,			
			),

		),
	);

	// Project Details In Class
	$meta_boxes[] = array(
		'title'			=> esc_html__( 'Project Details','kivicare' ),
		'post_types'	=> 'kivicareproject',
		'fields'		=> array(
					
			array(
				'id'		=> 'project_button',
				'name'		=> esc_html__( 'Button Name :','kivicare' ),				
				'type'		=> 'text'				
			),

			array(
				'id'		=> 'project_button_url',
				'name'		=> esc_html__( 'Button Link :','kivicare' ),				
				'type'		=> 'text'				
			),
		),
	);

	return $meta_boxes;
}
