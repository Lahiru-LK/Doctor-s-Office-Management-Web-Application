<?php

//box layout and full width layout container width

if (class_exists('ReduxFramework')) {
    add_action('wp_enqueue_scripts', 'kivicare_container_width', 21);
}

function kivicare_container_width()
{

    $kivicare_option = get_option('kivi_options');

    $box_container_width = "";

    if (isset($kivicare_option['opt-slider-label']) && !empty($kivicare_option['opt-slider-label']['width'])) {

        $container_width = $kivicare_option['opt-slider-label']['width'];
        if ($container_width !== 'px' && $container_width !== 'em' && $container_width !== '%') {
            $box_container_width = "
                body.iq-container-width .container,
                body.iq-container-width .elementor-section.elementor-section-boxed>.elementor-container {
                    max-width: " . $container_width . ";
                } ";
        }
    }

    // Custom extra css
    $custom_css = get_option('custom_css');

    // kivicare apply inline style
    wp_add_inline_style(
        'kivicare-style',
        $custom_css .
            $box_container_width
    );
}
