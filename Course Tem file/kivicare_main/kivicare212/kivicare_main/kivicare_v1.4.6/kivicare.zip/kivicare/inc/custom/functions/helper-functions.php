<?php
function kivicare_breadcrumbs_title_path()
{	
	$kivi_option = get_option('kivi_options');
    
  $title_tag = 'h2';
  
	if (isset($kivi_option['breadcum_title_tag'])) {
	    $title_tag = $kivi_option['breadcum_title_tag'];
	}
  if (is_archive()) { ?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php the_archive_title(); ?></<?php echo esc_attr($title_tag); ?>>
	<?php
    }
    elseif (is_search())
    {
        if (have_posts()): ?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php printf(esc_html__('Search Results for: %s', 'kivicare') , '<span>' . get_search_query() . '</span>'); ?></<?php echo esc_attr($title_tag); ?>>

	<?php
        else: ?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php esc_html_e('Nothing Found', 'kivicare'); ?></<?php echo esc_attr($title_tag); ?>>

	<?php
        endif;
    }
    elseif (is_404())
    {

        if (isset($kivi_option['kivi_fourzerofour_title']))
        {
?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php $four_title = $kivi_option['kivi_fourzerofour_title'];
            echo esc_html($four_title); ?></<?php echo esc_attr($title_tag); ?>>
	<?php
        }
        else
        {
?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php esc_html_e('Oops! That page can not be found.', 'kivicare'); ?></<?php echo esc_attr($title_tag); ?>>

	<?php
        }
    }
    elseif (is_home())
    { ?>
	<<?php echo esc_attr($title_tag); ?> class="title"><?php wp_title(''); ?></<?php echo esc_attr($title_tag); ?>>
	<?php
    }
    else
    { ?>
			<<?php echo esc_attr($title_tag); ?> class="title"><?php single_post_title(); ?></<?php echo esc_attr($title_tag); ?>>
	<?php
    } 
					
}

function kivicare_breadcrumbs_feature_image()
{
  $kivi_option = get_option('kivi_options');
  if(is_single())
  {
    return;
  }
                 
    $bnurl = '';
    $page_id = get_queried_object_id();

    if (has_post_thumbnail($page_id))
    {
        $image_array = wp_get_attachment_image_src(get_post_thumbnail_id($page_id) , 'full');
        $bnurl = $image_array[0];

    }
    else
    {
        if (is_404())
        {
            if (!empty($kivi_option['kivi_404_banner_image']['url']))
            {
                $bnurl = $kivi_option['kivi_404_banner_image']['url'];
            }
        }
        elseif (is_home())
        {
            if (!empty($kivi_option['kivi_blog_banner_image']['url']))
            {
                $bnurl = $kivi_option['kivi_blog_banner_image']['url'];
            }
        }
        else
        {
            if (!empty($kivi_option['kivi_page_banner_image']['url']))
            {
                $bnurl = $kivi_option['kivi_page_banner_image']['url'];
            }
        }
?>
	
<?php
    }
?>
<?php
    if (!empty($bnurl))
    {

?>
<img src="<?php echo esc_url($bnurl); ?>" class="img-fluid float-right" alt="<?php esc_attr_e('banner', 'kivicare'); ?>">
<?php
    } 
}

function kivicare_custom_breadcrumbs() {
    
     $show_on_home = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
     $home = ''.esc_html__('Home', 'kivicare').''; // text for the 'Home' link
     $show_current = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
    
     global $post;
     $home_link = esc_url(home_url());
    
     if (is_front_page()) {
    
       if ($show_on_home == 1) echo '<li class="breadcrumb-item"><a href="' . $home_link . '">' . $home . '</a></li>';
    
     } else {
    
       echo '<li class="breadcrumb-item"><a href="' . $home_link . '">' . $home . '</a></li> ';
    
        if( is_home()){
          echo  '<li class="breadcrumb-item active">'.esc_html__('Blogs', 'kivicare').'</li>';
       }elseif ( is_category() ) {
         $this_cat = get_category(get_query_var('cat'), false);
         if ($this_cat->parent != 0) echo '<li class="breadcrumb-item">'.get_category_parents($this_cat->parent, TRUE, '  ').'</li>';
         echo  '<li class="breadcrumb-item active">'.esc_html__('Archive by category : ', 'kivicare').' "' . single_cat_title('', false) . '" </li>';
    
       } elseif ( is_search() ) {
         echo  '<li class="breadcrumb-item active">'.esc_html__('Search results for : ', 'kivicare').' "' . get_search_query() . '"</li>';
       } elseif ( is_day() ) {
         echo '<li class="breadcrumb-item"><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a></li> ';
         echo '<li class="breadcrumb-item"><a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a></li>  ';
         echo  '<li class="breadcrumb-item active">'.get_the_time('d').'</li>';
    
       } elseif ( is_month() ) {
         echo '<li class="breadcrumb-item"><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a></li> ';
         echo  '<li class="breadcrumb-item active">'.get_the_time('F').'</li>';
       } elseif ( is_year() ) {
         echo  '<li class="breadcrumb-item active">'.get_the_time('Y').'</li>';
    
       } elseif ( is_single() && !is_attachment() ) {
         if ( get_post_type() != 'post' ) {
           $post_type = get_post_type_object(get_post_type());
           $slug = $post_type->rewrite;
           echo '<li class="breadcrumb-item"><a href="' . $home_link . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a></li>';
           if ($show_current == 1) echo '<li class="breadcrumb-item">'. get_the_title().'</li>';
         } else {
              $cat = get_the_category(); 
              if(!empty($cat))
              {
                $cat = $cat[0];
          
                if ($show_current == 0) $cat = preg_replace("#^(.+)\s\s$#", "$1", $cat);
                echo '<li class="breadcrumb-item">'.get_category_parents($cat, TRUE, '  ').'</li>';
                if ($show_current == 1) echo  '<li class="breadcrumb-item active">'.get_the_title().'</li>';
              }
              else
              {
                if ($show_current == 1) echo  '<li class="breadcrumb-item active">'.get_the_title().'</li>';
              }
         }
    
       } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
         $post_type = get_post_type_object(get_post_type());
         echo  '<li class="breadcrumb-item active">'.$post_type->labels->singular_name.'</li>';
    
       } elseif (  !is_single() && is_attachment() ) {
         $parent = get_post($post->post_parent);
         $cat = get_the_category($parent->ID); $cat = $cat[0];
         echo '<li class="breadcrumb-item">'.get_category_parents($cat, TRUE, '  ').'</li>';
         echo '<li class="breadcrumb-item"><a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a></li>';
         if ($show_current == 1) echo '<li class="breadcrumb-item active"> ' .  get_the_title().'</li>';
    
       } elseif ( is_page() && !$post->post_parent ) {
         if ($show_current == 1) echo  '<li class="breadcrumb-item active">'.get_the_title().'</li>';
    
       } elseif ( is_page() && $post->post_parent ) {
         $parent_id  = $post->post_parent;
         $breadcrumbs = array();
         while ($parent_id) {
           $page = get_page($parent_id);
           $breadcrumbs[] = '<li class="breadcrumb-item"><a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a></li>';
           $parent_id  = $page->post_parent;
         }
         $breadcrumbs = array_reverse($breadcrumbs);
         
         if ($show_current == 1) echo '<li class="breadcrumb-item active"> ' .  get_the_title().'</li>';
    
       } elseif ( is_tag() ) {
         echo  '<li class="breadcrumb-item active">'.esc_html__('Posts tagged', 'kivicare').' "' . single_tag_title('', false) . '"</li>';
    
       } elseif ( is_author() ) {
          global $author;
         $userdata = get_userdata($author);
         echo  '<li class="breadcrumb-item active">'.esc_html__('Articles posted by : ', 'kivicare').' ' . $userdata->display_name.'</li>';
    
       } elseif ( is_404() ) {
         echo  '<li class="breadcrumb-item active">'.esc_html__('Error 404', 'kivicare').'</li>';
       }

       if ( get_query_var('paged') ) {
         if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
         echo '<li class="breadcrumb-item">'. esc_html__('Page','kivicare') . ' ' . get_query_var('paged').'</li>';
         if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
       }    
     }
}

function kivicare_departments_menu() {
  register_nav_menu('kivi-departments-menu',esc_html__( 'Iqonic Menu','kivicare' ));
}
add_action( 'init', 'kivicare_departments_menu' );
