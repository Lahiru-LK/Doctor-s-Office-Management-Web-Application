<?php
if ( !function_exists( 'kivicare_create_dynamic_style' ) ) {

    function kivicare_create_dynamic_style() {

        $kivicare_dynamic_css = array();
        $kivicare_dynamic_css_min_width_1200px = array();

        $kivi_option = get_option('kivi_options');

        $loader_width = '';
        $loader_height = '';

        if(!empty($kivi_option["logo-dimensions"]["width"])) { $logo_width = $kivi_option["logo-dimensions"]["width"]; }
        if(!empty($kivi_option["logo-dimensions"]["height"])) { $logo_height = $kivi_option["logo-dimensions"]["height"]; }

        if(!empty($kivi_option["vertical-logo-dimensions"]["width"])) { $vertical_logo_width = $kivi_option["vertical-logo-dimensions"]["width"]; }
        if(!empty($kivi_option["vertical-logo-dimensions"]["height"])) { $vertical_logo_height = $kivi_option["vertical-logo-dimensions"]["height"]; }

        if(!empty($kivi_option["loader-dimensions"]["width"])) {  $loader_width = $kivi_option["loader-dimensions"]["width"]; }
        if(!empty($kivi_option["loader-dimensions"]["height"])) { $loader_height = $kivi_option["loader-dimensions"]["height"]; }

        if(isset($kivi_option["body_font"]["font-family"])) { $body_family = $kivi_option["body_font"]["font-family"]; }
        if(isset($kivi_option["body_font"]["font-backup"])) { $body_backup = $kivi_option["body_font"]["font-backup"]; }
        if(isset($kivi_option["body_font"]["font-size"])){ $body_size = $kivi_option["body_font"]["font-size"]; }
        if(isset($kivi_option["body_font"]["font-weight"])){ $body_weight = $kivi_option["body_font"]["font-weight"]; }

        if(isset($kivi_option["h1_font"]["font-family"])) { $h1_family = $kivi_option["h1_font"]["font-family"]; }
        if(isset($kivi_option["h1_font"]["font-size"])) { $h1_size = $kivi_option["h1_font"]["font-size"]; }
        if(isset($kivi_option["h1_font"]["font-weight"])) { $h1_weight = $kivi_option["h1_font"]["font-weight"]; }

        if(isset($kivi_option["h2_font"]["font-family"])) { $h2_family = $kivi_option["h2_font"]["font-family"]; }
        if(isset($kivi_option["h2_font"]["font-size"])) { $h2_size = $kivi_option["h2_font"]["font-size"]; }
        if(isset($kivi_option["h2_font"]["font-weight"])) { $h2_weight = $kivi_option["h2_font"]["font-weight"]; }

        if(isset($kivi_option["h3_font"]["font-family"])) { $h3_family = $kivi_option["h3_font"]["font-family"]; }
        if(isset($kivi_option["h3_font"]["font-size"])) { $h3_size = $kivi_option["h3_font"]["font-size"]; }
        if(isset($kivi_option["h3_font"]["font-weight"])) { $h3_weight = $kivi_option["h3_font"]["font-weight"]; }

        if(isset($kivi_option["h4_font"]["font-family"])) { $h4_family = $kivi_option["h4_font"]["font-family"]; }
        if(isset($kivi_option["h4_font"]["font-size"])) { $h4_size = $kivi_option["h4_font"]["font-size"]; }
        if(isset($kivi_option["h4_font"]["font-weight"])) { $h4_weight = $kivi_option["h4_font"]["font-weight"]; }

        if(isset($kivi_option["h5_font"]["font-family"])) { $h5_family = $kivi_option["h5_font"]["font-family"]; }
        if(isset($kivi_option["h5_font"]["font-size"])) { $h5_size = $kivi_option["h5_font"]["font-size"]; }
        if(isset($kivi_option["h5_font"]["font-weight"])) { $h5_weight = $kivi_option["h5_font"]["font-weight"]; }

        if(isset($kivi_option["h6_font"]["font-family"])) { $h6_family = $kivi_option["h6_font"]["font-family"]; }
        if(isset($kivi_option["h6_font"]["font-size"])) { $h6_size = $kivi_option["h6_font"]["font-size"]; }
        if(isset($kivi_option["h6_font"]["font-weight"])) { $h6_weight = $kivi_option["h6_font"]["font-weight"]; }


        if(!empty($logo_width)){
            $kivicare_dynamic_css[] = array(
                        'elements'  =>  'header.style-one a.navbar-brand img, .vertical-navbar-brand img',
                        'property'  =>  'width',
                        'value'     =>  $logo_width. '!important'
                    );
            }



        if(!empty($logo_height)){
            $kivicare_dynamic_css[] = array(
                        'elements'  =>  'header.style-one a.navbar-brand img, .vertical-navbar-brand img',
                        'property'  =>  'height',
                        'value'     =>  $logo_height. '!important'
                    );
            }

        if(!empty($vertical_logo_width)){
            $kivicare_dynamic_css[] = array(
                        'elements'  =>  'header.style-vertical a.navbar-brand img',
                        'property'  =>  'width',
                        'value'     =>  $vertical_logo_width. '!important'
                    );
            }

        if(!empty($vertical_logo_height)){
            $kivicare_dynamic_css[] = array(
                        'elements'  =>  'header.style-vertical a.navbar-brand img',
                        'property'  =>  'height',
                        'value'     =>  $vertical_logo_height. '!important'
                    );
            }

        if(!empty($loader_width)){
                $kivicare_dynamic_css[] = array(
                    'elements'  =>  '#loading img',
                    'property'  =>  'width',
                    'value'     =>  $loader_width. '!important'
                );
            }

        if(!empty($loader_height)){
                $kivicare_dynamic_css[] = array(
                    'elements'  =>  '#loading img',
                    'property'  =>  'height',
                    'value'     =>  $loader_height. '!important'
                );
            }

        if(!empty($kivi_option['header_radio']) && $kivi_option['header_radio'] == 1 ){
            if(!empty($header_font_family)){
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-family',
                'value'     =>  $header_font_family. '!important'
            );
            }

            if(!empty($header_font_size)){
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-size',
                'value'     =>  $header_font_size. '!important'
            );
            }

            if(!empty($header_font_weight)){
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-weight',
                'value'     =>  $header_font_weight. '!important'
            );
            }
        }

        // Change font 1
        if( isset($kivi_option['kivi_change_font']) && $kivi_option['kivi_change_font'] == 1 ){

            // body
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'body',
                'property'  =>  'font-family',
                'value'     =>  $body_family.  $body_backup. '!important'
            );

            $kivicare_dynamic_css[] = array(
                'elements'  =>  'body',
                'property'  =>  'font-size',
                'value'     =>  $body_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'body',
                'property'  =>  'font-weight',
                'value'     =>  $body_weight. '!important'
            );

            // h2 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-family',
                'value'     =>  $h1_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-size',
                'value'     =>  $h1_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h1',
                'property'  =>  'font-weight',
                'value'     =>  $h1_weight. '!important'
            );

            // h2 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h2',
                'property'  =>  'font-family',
                'value'     =>  $h2_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h2',
                'property'  =>  'font-size',
                'value'     =>  $h2_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h2',
                'property'  =>  'font-weight',
                'value'     =>  $h2_weight. '!important'
            );

            // h3 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h3',
                'property'  =>  'font-family',
                'value'     =>  $h3_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h3',
                'property'  =>  'font-size',
                'value'     =>  $h3_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h3',
                'property'  =>  'font-weight',
                'value'     =>  $h3_weight. '!important'
            );

            // h4 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h4',
                'property'  =>  'font-family',
                'value'     =>  $h4_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h4',
                'property'  =>  'font-size',
                'value'     =>  $h4_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h4',
                'property'  =>  'font-weight',
                'value'     =>  $h4_weight. '!important'
            );

            // h5 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h5',
                'property'  =>  'font-family',
                'value'     =>  $h5_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h5',
                'property'  =>  'font-size',
                'value'     =>  $h5_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h5',
                'property'  =>  'font-weight',
                'value'     =>  $h5_weight. '!important'
            );

            // h6 menu
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h6',
                'property'  =>  'font-family',
                'value'     =>  $h6_family. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h6',
                'property'  =>  'font-size',
                'value'     =>  $h6_size. '!important'
            );
            $kivicare_dynamic_css[] = array(
                'elements'  =>  'h6',
                'property'  =>  'font-weight',
                'value'     =>  $h6_weight. '!important'
            );

        }

        // Start generating if related arrays are populated
        if ( count( $kivicare_dynamic_css ) > 0 ) {
            echo "<style type='text/css' id='kivicare-dynamic-css'>\n\n";

            // Basic dynamic CSS
            if ( count( $kivicare_dynamic_css ) > 0 ) {
                kivicare_dynamic_style( $kivicare_dynamic_css );
            }
            echo '</style>';
        }
    }
}
add_action( 'wp_head', 'kivicare_create_dynamic_style' );

if ( !function_exists( 'kivicare_create_dynamic_style' ) ) {

    function kivicare_create_dynamic_style() {

        $kivicare_dynamic_css = array();
        $kivicare_dynamic_css_min_width_1200px = array();

        $kivi_option = get_option('kivi_options');

        $loader_width = '';
        $loader_height = '';

        if(!empty($kivi_option["logo-dimensions"]["width"])) { $logo_width = $kivi_option["logo-dimensions"]["width"]; }
        if(!empty($kivi_option["logo-dimensions"]["height"])) { $logo_height = $kivi_option["logo-dimensions"]["height"]; }

        if(!empty($kivi_option["loader-dimensions"]["width"])) { $loader_width = $kivi_option["loader-dimensions"]["width"]; }
        if(!empty($kivi_option["loader-dimensions"]["height"])) { $loader_height = $kivi_option["loader-dimensions"]["height"]; }


        $kivicare_dynamic_css[] = array(
            'elements'  =>  '.navbar-brand img, .vertical-navbar-brand img',
            'property'  =>  'width',
            'value'     =>  $logo_width. '!important'
        );
        $kivicare_dynamic_css[] = array(
            'elements'  =>  '.navbar-brand img, .vertical-navbar-brand img',
            'property'  =>  'height',
            'value'     =>  $logo_height. '!important'
        );



        // Start generating if related arrays are populated
        if ( count( $kivicare_dynamic_css ) > 0 ) {
            echo "<style type='text/css' id='kivicare-dynamic-css'>\n\n";

            // Basic dynamic CSS
            if ( count( $kivicare_dynamic_css ) > 0 ) {
                kivicare_dynamic_style( $kivicare_dynamic_css );
            }
            echo '</style>';
        }
    }
}
add_action( 'wp_head', 'kivicare_create_dynamic_style' );
