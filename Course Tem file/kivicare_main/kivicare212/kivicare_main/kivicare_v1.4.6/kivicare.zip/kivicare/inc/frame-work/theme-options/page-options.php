<?php
/*
 * blog Options
 */
$opt_name;
Redux::set_section( $opt_name, array(
    'title' => esc_html__('Page Settings','kivicare'),
    'id'    => 'page-section',
    'icon'  => 'el el-cog',
    'fields'=> array(
        

        array(
            'id'        => 'kivi_page_variation',
            'type'      => 'image_select',
            'title'     => esc_html__( 'Page Setting','kivicare' ),
            'subtitle'  => wp_kses( __( '<br />Choose among these structures (Right Sidebar, Left Sidebar and 1column) for your Page.<br />To filling these column sections you should go to appearance > widget.<br />And put every widget that you want in these sections.','kivicare' ), array( 'br' => array() ) ),            
            'options'   => array(
                '1' => array( 'title' => esc_html__( 'Full Width','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/single-column.jpg' ),                                 
                '2' => array( 'title' => esc_html__( 'Right Sidebar','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/right-side.jpg' ),
                '3' => array( 'title' => esc_html__( 'Left Sidebar','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/left-side.jpg' ),                     
            ),
            'default'   => '1',
        ),

        array(
            'id'        => 'kivi_search_variation',
            'type'      => 'image_select',
            'title'     => esc_html__( 'Search page Setting','kivicare' ),
            'subtitle'  => wp_kses( __( '<br />Choose among these structures (Right Sidebar, Left Sidebar and 1column) for your Search page.<br />To filling these column sections you should go to appearance > widget.<br />And put every widget that you want in these sections.','kivicare' ), array( 'br' => array() ) ),            
            'options'   => array(
                '1' => array( 'title' => esc_html__( 'Full Width','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/single-column.jpg' ),                                
                '2' => array( 'title' => esc_html__( 'Right Sidebar','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/right-side.jpg' ),
                '3' => array( 'title' => esc_html__( 'Left Sidebar','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/left-side.jpg' ), 
            ),
            'default'   => '1',
        ),
        
    )
));
