<?php
$opt_name;
Redux::set_section( $opt_name, array(
    'title' => esc_html__('404','kivicare'),
    'id'    => 'fourzerofour-section',
    'icon'  => 'el-icon-error',
    'desc'  => esc_html__('This section contains options for 404.','kivicare'),
    'fields'=> array(

        array(
            'id'       => 'kivi_404_banner_image',         
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( '404 Page Default Banner Image','kivicare'),
            'read-only'=> false,
            'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/backend/404.png' ),
            'subtitle' => esc_html__( 'Upload banner image for your Website. Otherwise blank field will be displayed in place of this section.','kivicare'),
        ),

        array(
            'id'        => 'kivi_fourzerofour_title',
            'type'      => 'text',
            'title'     => esc_html__( '404 Page Title','kivicare'),
            'default'   => esc_html__( 'Oops! This Page is Not Found.','kivicare' )
        ),
        array(
            'id'        => 'kivi_four_description',
            'type'      => 'textarea',
            'title'     => esc_html__( '404 Page Description','kivicare'),
            'default'   => esc_html__( 'The requested page does not exist.','kivicare' )
        ),
    )) 
);
