<?php
if(!class_exists('ReduxFramework'))
{
    return;
}

add_action( 'wp_head', 'kivicare_header_top_background_style' );
add_action( 'wp_head', 'kivicare_top_text_color_options');

function kivicare_header_top_background_style()
{
    $kivi_option = get_option('kivi_options');
    $dynamic_css = array();
    if(isset($kivi_option['header_top_background_type']) && $kivi_option['header_top_background_type'] != 'default')
    {
        $type = $kivi_option['header_top_background_type'];
        if($type == 'color')
        {
            if(!empty($kivi_option['header_top_background_color']))
            {
                $dynamic_css[] = array(
                'elements'  =>  'header .sub-header',
                'property'  =>  'background',
                'value'     =>  ''.$kivi_option['header_top_background_color'].' !important'
                );
            }
        }
        if($type == 'image')
        {
            if(!empty($kivi_option['header_top_background_image']['url']))
            {
                $dynamic_css[] = array(
                'elements'  =>  'header .sub-header',
                'property'  =>  'background',
                'value'     =>  'url('.$kivi_option['header_top_background_image']['url'].') !important'
                );
            }
        }
        if($type == 'transparent')
        {

            $dynamic_css[] = array(
            'elements'  =>  'header .sub-header',
            'property'  =>  'background',
            'value'     =>  'transparent !important'
            );
        }
    }
    if ( count( $dynamic_css ) > 0 )
    {
        echo "<style type='text/css' id='kivicare-dynamic-css".rand(10,100000)."'>\n\n";
            kivicare_dynamic_style( $dynamic_css );
        echo '</style>';
    }
}
function kivicare_top_text_color_options()
{
    $kivi_option = get_option('kivi_options');

    $inline_css = '';
    
    if(isset($kivi_option['header_top_text_color_type']) && $kivi_option['header_top_text_color_type'] != 'default')
    { 
        if(isset($kivi_option['header_top_text_color']) && !empty($kivi_option['header_top_text_color']))
        {
            
            $inline_css .= 'header.style-one .sub-header .number-info li a,header .sub-header  li a,header.style-one .sub-header .number-info li a i{
                color : '.$kivi_option['header_top_text_color'].'!important;
            }';
        }
        if(isset($kivi_option['header_top_text_hover_color']) && !empty($kivi_option['header_top_text_hover_color']))
        {
            $inline_css .= ' header.style-one .sub-header .number-info li:hover a,header .sub-header  li:hover a,header.style-one .sub-header .number-info li:hover a i{
                color : '.$kivi_option['header_top_text_hover_color'].'!important;
            }';
        }
         if(isset($kivi_option['header_top_icon_color']) && !empty($kivi_option['header_top_icon_color']))
        {
            $inline_css .= '
                header.style-one .sub-header .social-icone ul li i, 
                header.style-one .sub-header .number-info li a i {
                color : '.$kivi_option['header_top_icon_color'].'!important;
            }';
        }
        if(isset($kivi_option['header_top_icon_hover_color']) && !empty($kivi_option['header_top_icon_hover_color']))
        {
            $inline_css .= '
                header.style-one .sub-header .social-icone ul li:hover i,
                header.style-one .sub-header .number-info li:hover a i{
                color : '.$kivi_option['header_top_icon_hover_color'].'!important;
            }';
        }               
    }

    if(!empty($inline_css))
    {
        wp_register_style( 'kivicare-top-header-style', false );
        wp_enqueue_style( 'kivicare-top-header-style' );
        wp_add_inline_style('kivicare-top-header-style', $inline_css );
    }   
}
