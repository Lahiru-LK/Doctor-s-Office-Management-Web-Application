<?php
global $kivi_option;
// TGM plugin activation
require_once get_template_directory() . '/inc/tgm/required-plugins.php';
// Breadcrumbs
require_once get_template_directory() . '/inc/custom/breadcrumbs.php';
// Demo import
require_once get_template_directory() . '/inc/demo/import.php';
// Header Breadcrumbs
require_once get_template_directory() . '/inc/custom/breadcrumbs.php';
// Comment
require_once get_template_directory() . '/inc/custom/comment.php';
// Pagination
require_once get_template_directory() . '/inc/custom/pagination.php';
// Widget
require_once get_template_directory() . '/inc/custom/widget.php';
// Dynamic Style
require_once get_template_directory() . '/inc/custom/dynamic-style.php';
// Color Style
require_once get_template_directory() . '/inc/custom/color-style.php';
require_once get_template_directory() . '/inc/custom/dynamic-style/init.php';
//Healper Function
require_once get_template_directory() . '/inc/custom/functions/helper-functions.php';

function kivicare_custom_fonts_url()
{
    $fonts_url = '';
    $heebo = _x('on', 'Heebo: on or off', 'kivicare');
    $roboto = _x('on', 'Roboto: on or off', 'kivicare');

    if ('off' !== $heebo || 'off' !== $roboto) {
        $font_families = array();
        $font_families[] = 'Heebo:wght@200;300;400;500;600;700;800&family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700';
        $query_args = array(
            'family' => implode('&family', $font_families),
            'subset' => urlencode('latin,latin-ext'),
        );
        $fonts_url = add_query_arg($query_args, '//fonts.googleapis.com/css2');
    }

    return esc_url_raw($fonts_url);
}

function kivicare_load_js_css()
{


    wp_enqueue_script('jquery');
    /* Custom JS */
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '1.3.0', true);
    wp_enqueue_script('appear', get_template_directory_uri() . '/assets/js/appear.js', array(), '1.0', true);
    wp_enqueue_script('wow', get_template_directory_uri() . '/assets/js/wow.min.js', array(), '1.0', true);
    wp_enqueue_script('skrollr', get_template_directory_uri() . '/assets/js/skrollr.js', array(), '1.0', true);
    wp_enqueue_script('kivicare-custom', get_template_directory_uri() . '/assets/js/kivicare-custom.js', array(), '1.0', true);


    /* Custom CSS */
    wp_enqueue_style('kivicare-fonts', kivicare_custom_fonts_url(), array(), null);

    wp_enqueue_style('wow', get_template_directory_uri() . '/assets/css/wow.css', array(), '3.7.0', 'all');
    wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.min.css', array(), '4.1.3', 'all');
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '4.1.3', 'all');
    wp_enqueue_style('ionicons', get_template_directory_uri() . '/assets/css/ionicons/css/ionicons.min.css', array(), '4.5.10', 'all');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome/css/font-awesome.min.css', array(), '4.7.0', 'all');

    wp_enqueue_style('kivicare-style', get_template_directory_uri() . '/assets/css/kivicare-style.css', array(), '1.0', 'all');

    wp_enqueue_script('wishlist-custom', get_template_directory_uri() . '/woocommerce/assets/kivicare-wishlist.js', array(), '1.0', true);
    wp_enqueue_style('kivicare-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array(), '1.0', 'all');
}

add_action('wp_enqueue_scripts', 'kivicare_load_js_css');

function kivicare_searchfilter($query)
{
    if(!is_admin()){
        if ($query->is_search) {
            $query->set('post_type', 'post');
        }
        return $query;
    }    
}

add_filter('pre_get_posts', 'kivicare_searchfilter');
if (!function_exists('kivicare_dynamic_style')) {

    function kivicare_dynamic_style($kivicare_css_array)
    {
        foreach ($kivicare_css_array as $css_part) {
            if (!empty($css_part['value'])) {
                echo esc_attr($css_part['elements']) . "{\n";
                echo esc_attr($css_part['property']) . ":" . esc_attr($css_part['value']) . ";\n";
                echo "}\n\n";
            }
        }
    }
}

add_filter('wp_list_categories', 'kivicare_categories_postcount_filter');
function kivicare_categories_postcount_filter($variable)
{
    $variable = str_replace('(', '<span class="post_count"> ', $variable);
    $variable = str_replace(')', ' </span>', $variable);
    return $variable;
}

add_filter('get_archives_link', 'kivicare_style_the_archive_count');
function kivicare_style_the_archive_count($links){
    $links = str_replace('</a>&nbsp;(', '</a> <span class="archiveCount">', $links);
    $links = str_replace(')</li>', '</li></span>', $links);
    return $links;
}

function kivicare_inline_css()
{
    $kivi_option = get_option('kivi_options');
    $custom_style = "";

    if (!empty($kivi_option['kivi_css_code'])) {

        $kivi_css_code = $kivi_option['kivi_css_code'];
        $custom_style = esc_attr($kivi_css_code);
    }
    wp_add_inline_style('kivicare-style', $custom_style);
}

add_action('wp_enqueue_scripts', 'kivicare_inline_css', 100);

/* Remove inline caption for themes */

add_filter('img_caption_shortcode', 'kivicare_img_caption_filter', 10, 3);

function kivicare_img_caption_filter($empty, $attr, $content)
{
    $attr = shortcode_atts(array(
        'id' => '',
        'align' => 'alignnone',
        'width' => '',
        'caption' => ''
    ), $attr);

    if (1 > (int)$attr['width'] || empty($attr['caption'])) {
        return '';
    }

    if ($attr['id']) {
        $attr['id'] = 'id="' . esc_attr($attr['id']) . '" ';
    }

    return '<div ' . $attr['id']
        . 'class="wp-caption ' . esc_attr($attr['align']) . '" '
        . 'style="max-width: ' . (10 + (int)$attr['width']) . 'px;">'
        . do_shortcode($content)
        . '<p class="wp-caption-text">' . $attr['caption'] . '</p>'
        . '</div>';

}

/* Body Class */
if (class_exists('ReduxFramework')) {
    function kivicare_body_classes_add($classes)
    {
        $classes[] = 'iq-container-width';

        return $classes;
    }

    add_filter('body_class', 'kivicare_body_classes_add');
}

// refresh mini cart ------------//
add_filter('woocommerce_add_to_cart_fragments', 'wc_refresh_mini_cart_count');
function wc_refresh_mini_cart_count($fragments)
{
    ob_start(); ?>
    <div id="mini-cart-count">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </div>
    <?php $fragments['#mini-cart-count'] = ob_get_clean();
    return $fragments;
}

add_filter('woocommerce_add_to_cart_fragments', 'kivicare_refresh_mini_cart_count');
function kivicare_refresh_mini_cart_count($fragments)
{
    ob_start(); ?>
    <div id="mini-cart-count">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </div>
    <?php $fragments['#mini-cart-count'] = ob_get_clean();
    return $fragments;
}

// refresh wishlist ------------//
if (defined('YITH_WCWL') && !function_exists('kivicare_yith_wcwl_ajax_update_count')) {
    function kivicare_yith_wcwl_ajax_update_count()
    {
        wp_send_json(array('count' => yith_wcwl_count_all_products()));
    }

    add_action('wp_ajax_yith_wcwl_update_wishlist_count', 'kivicare_yith_wcwl_ajax_update_count');
    add_action('wp_ajax_nopriv_yith_wcwl_update_wishlist_count', 'kivicare_yith_wcwl_ajax_update_count');
}

add_action('admin_head', 'kivicare_admin_custom_fonts');

function kivicare_admin_custom_fonts()
{
	echo '<style>.redux-container .ui-button {
    height: unset;
}
  </style>';
}


add_action('admin_notices', 'kivicare_update_plugin_notice', -1);

function kivicare_update_plugin_notice() {
        // PLugin And Theme Required Version
        $required_iqonic_extension_version = '1.4.6';

        // Plugin And Theme Current Version
        $iqonic_extension_version =  defined('IQ_TH_ROOT') ? get_plugin_data(IQ_TH_ROOT . '/index.php')['Version'] : 0;

        if (defined('ELEMENTOR_VERSION') && ELEMENTOR_VERSION > '3.6.0' && ($iqonic_extension_version < $required_iqonic_extension_version ) ) {
?>
            <div class="notice notice-warning kivicare-notice  is-dismissible" id="kivicare_notification_5_0_0">
                <div class="kivicare-notice-main-box d-flex">

                    <div class="kivicare-notice-message">
                        <h3><?php esc_html_e('Elementor New Update is Out Now!', 'kivicare'); ?>
                            <a class="" href="<?php echo esc_url('https://assets.iqonic.design/documentation/wordpress/update-doc/index.html', 'kivicare') ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Check Here - How To Update Plugin', 'kivicare') ?></a>
                        </h3>
                        <?php
                        if ((is_plugin_active('iqonic-extensions/index.php') && $iqonic_extension_version <   $required_iqonic_extension_version ) ){
                        ?>
                            <div class="kivicare-notice-message-inner">
                                <strong class="text-bold "><?php esc_html_e('Update Theme Required Plugins  ', 'kivicare'); ?></strong>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
                <div class="kivicare-notice-cta">
                    <button class="kivicare-notice-dismiss kivicare-dismiss-welcome notice-dismiss" data-msg="kivicare_notification_5_0_0"><span class="screen-reader-text"><?php esc_html_e('Dismiss', 'kivicare'); ?></span></button>
                </div>
            </div>
<?php
        }
    }

	add_action('admin_enqueue_scripts', 'kivicare_selectively_enqueue_admin_script');
	function kivicare_selectively_enqueue_admin_script()
    {
        wp_enqueue_script('admin-custom', get_template_directory_uri() . '/assets/js/admin-custom.min.js', array());
        wp_enqueue_style('admin-custom', get_template_directory_uri() . '/assets/css/admin-custom.min.css');
    }