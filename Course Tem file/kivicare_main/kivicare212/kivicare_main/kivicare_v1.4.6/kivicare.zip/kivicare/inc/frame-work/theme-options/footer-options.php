<?php
/*
 * Footer Options
 */
$opt_name;
Redux::set_section( $opt_name, array(
    'title' => esc_html__( 'Footer', 'kivicare' ),
    'id'    => 'footer-editor',
    'icon'  => 'el el-arrow-down',
    'customizer_width' => '500px',
) );

Redux::set_section( $opt_name, array(
    'title' => esc_html__('Footer Image','kivicare'),
    'id'    => 'footer-logo',
    'subsection' => true,
    'desc'  => esc_html__('This section contains options for footer.','kivicare'),
    'fields'=> array(

        array(
            'id'        => 'display_footer',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Footer Background Image','kivicare'),
            'subtitle' => esc_html__( 'Display Footer Background Image On All page', 'kivicare' ),
            'options'   => array(
                            'yes' => esc_html__('Yes','kivicare'),
                            'no' => esc_html__('No','kivicare')
                        ),
            'default'   => esc_html__('no','kivicare')
        ),

        array(
            'id'       => 'logo_footer',         
            'type'     => 'media',
            'url'      => false,
            'title'    => esc_html__( 'Footer Logo','kivicare'),            
            'read-only'=> false,
            'subtitle' => esc_html__( 'Upload Footer Logo for your Website.','kivicare'),
            'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/logo.png' ),
        ),

        array(
            'id'       => 'footer_image',
            'type'     => 'media',
            'url'      => false,
            'title'    => esc_html__( 'Footer Background Image','kivicare'),
            'required'  => array( 'display_footer', '=', 'yes' ),
            'read-only'=> false,
            'subtitle' => esc_html__( 'Upload Footer image for your Website.','kivicare'),
            'default'  => array( 'url' => get_template_directory_uri() .'/assets/images/footer-img.jpg' ),
        ),

        array(
            'id'        => 'change_footer_color',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Change Footer Color','kivicare'),
            'subtitle' => esc_html__( 'Turn on to Change Footer Background Color', 'kivicare' ),
            'options'   => array(
                            '0' => esc_html__('Yes','kivicare'),
                            '1' => esc_html__('No','kivicare')
                        ),
            'default'   => esc_html__('0','kivicare')
        ),

        array(
            'id'            => 'footer_color',
            'type'          => 'color',
            'subtitle'      => esc_html__( 'Choose Footer Background Color', 'kivicare' ),
            'required'  => array( 'change_footer_color', '=', '0' ),
            'default'       =>'#eff1fe',
            'mode'          => 'background',
            'transparent'   => false
        ),

    )
));

Redux::set_section( $opt_name, array(
    'title' => esc_html__('Footer Option','kivicare'),
    'id'    => 'footer-section',
    'subsection' => true,
    'desc'  => esc_html__('This section contains options for footer.','kivicare'),
    'fields'=> array(

        array(
            'id'        => 'kivi_footer_top',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Footer Top','kivicare'),
            'subtitle' => esc_html__( 'Display Footer Top On All page', 'kivicare' ),
            'options'   => array(
                            'yes' => esc_html__('Yes','kivicare'),
                            'no' => esc_html__('No','kivicare')
                        ),
            'default'   => esc_html__('yes','kivicare')
        ),

        array(
            'id'        => 'kivi_footer_width',
            'type'      => 'image_select',
            'title'     => esc_html__( 'Footer Layout Type','kivicare' ),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'subtitle'  => wp_kses( __( '<br />Choose among these structures (1column, 2column and 3column) for your footer section.<br />To fill these column sections you should go to appearance > widget.<br />And add widgets as per your needs.','kivicare' ), array( 'br' => array() ) ),
            'options'   => array(
                                '1' => array( 'title' => esc_html__( 'Footer Layout 1','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/footer_first.png' ),
                                '2' => array( 'title' => esc_html__( 'Footer Layout 2','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/footer_second.png' ),
                                '3' => array( 'title' => esc_html__( 'Footer Layout 3','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/footer_third.png' ),
                                '4' => array( 'title' => esc_html__( 'Footer Layout 4','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/footer_four.png' ),
                                '5' => array( 'title' => esc_html__( 'Footer Layout 5','kivicare' ), 'img' => get_template_directory_uri() . '/assets/images/backend/footer_five.png' ),
                            ),
            'default'   => '3',
        ),

        array(
            'id'       => 'footer_one',
            'type'     => 'select',
            'title'    => esc_html__('Select 1 Footer Alignment', 'kivicare'),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '1',
        ),

        array(
            'id'       => 'footer_two',
            'type'     => 'select',
            'title'    => esc_html__('Select 2 Footer Alignment', 'kivicare'),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '1',
        ),

        array(
            'id'       => 'footer_three',
            'type'     => 'select',
            'title'    => esc_html__('Select 3 Footer Alignment', 'kivicare'),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '1',
        ),

        array(
            'id'       => 'footer_fore',
            'type'     => 'select',
            'title'    => esc_html__('Select 4 Footer Alignment', 'kivicare'),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '1',
        ),

        array(
            'id'       => 'footer_five',
            'type'     => 'select',
            'title'    => esc_html__('Select 5 Footer Alignment', 'kivicare'),
            'required'  => array( 'kivi_footer_top', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '1',
        ),
    )
));

Redux::set_section( $opt_name, array(
    'title'      => esc_html__( 'Footer Copyright', 'kivicare' ),
    'id'         => 'footer-copyright',
    'subsection' => true,
    'fields'     => array(

        array(
            'id'        => 'display_copyright',
            'type'      => 'button_set',
            'title'     => esc_html__( 'Display Copyrights','kivicare'),
            'options'   => array(
                            'yes' => esc_html__('Yes','kivicare'),
                            'no' => esc_html__('No','kivicare')
                        ),
            'default'   => esc_html__('yes','kivicare')
        ),
         array(
            'id'       => 'footer_copyright_align',
            'type'     => 'select',
            'title'    => esc_html__('Copyrights Alignment', 'kivicare'),
            'required'  => array( 'display_copyright', '=', 'yes' ),
            'options'  => array(
                '1' => 'Left',
                '2' => 'Right',
                '3' => 'Center',
            ),
            'default'  => '2',
        ),


        array(
            'id'        => 'footer_copyright',
            'type'      => 'editor',
            'required'  => array( 'display_copyright', '=', 'yes' ),
            'title'     => esc_html__( 'Copyrights Text','kivicare'),
            'default'   => esc_html__( 'Copyright 2020 kivicare All Rights Reserved.','kivicare'),
        ),

    ))
);
