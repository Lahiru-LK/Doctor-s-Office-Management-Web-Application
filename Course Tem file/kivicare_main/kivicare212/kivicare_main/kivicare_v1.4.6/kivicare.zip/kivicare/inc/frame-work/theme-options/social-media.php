<?php
/*
 * Social Network Options
 */
$opt_name;
Redux::set_section( $opt_name, array(
    'title'            => esc_html__( 'Social Media', 'kivicare' ),
    'id'               => 'social_link',
    'icon'             => 'el-icon-share',  
    'fields'           => array(
                
        array(
            'id'       => 'social-media-iq',
            'type'     => 'sortable',
            'title'    => esc_html__('Social Media Option', 'kivicare'),
            'subtitle' => esc_html__('Enter social media url.', 'kivicare'),
            'mode'     => 'text',
			'label'    => true,
            'options'  => array(
				'facebook'     => '',
				'twitter'        => '',
				'google-plus'  => '',
                'github'      	 => '',
				'instagram'      => '',
                'linkedin'       => '',
                'tumblr'         => '',
                'pinterest'      => '',
                'dribbble'       => '',
                'reddit'         => '',
                'flickr'         => '',
                'skype'          => '',
                'youtube-play'   => '',
                'vimeo'          => '',
                'soundcloud'     => '',
                'wechat'         => '',
                'renren'         => '',
                'weibo'          => '',
                'xing'           => '',
                'qq'             => '',
                'rss'            => '',
                'vk'             => '',
                'behance'        => '',
                'snapchat'       => '',
            ),
        ),
        
    ),
) );
