<?php
/*
 * Header Options
 */
$opt_name;
Redux::set_section( $opt_name, array(
    'title'      => esc_html__( 'MailChimp Subscribe', 'kivicare' ),
    'id'         => 'kivicare-subscribe',
    'icon'       => 'el el-envelope',
    'fields'     => array(

        array(
            'id'        => 'kivi_subscribe',
            'type'      => 'text',
            'title'     => esc_html__( 'Subscribe Shortcode','kivicare'),
            'subtitle'  => esc_html__( 'Put you Mailchimp for WP Shortcode here','kivicare' ),
        ),

    )) 
);
