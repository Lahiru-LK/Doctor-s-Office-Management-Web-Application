<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="iq-blog-box">	
		<?php
		$kivi_option = get_option('kivi_options');
		if(isset($kivi_option['kivi_display_image']))
		{
		$options = $kivi_option['kivi_display_image'];
		if($options == "yes"){
			if ( has_post_thumbnail() ) { ?>
			<div class="iq-blog-image">
				<?php the_post_thumbnail(); ?>
			</div>	
			<?php } 
		} 
		} ?>

		<div class="iq-blog-detail">

		    <div class="iq-blog-cat"> <?php 

				$postcat = wp_get_post_terms(get_the_ID(), 'category');
				if ($postcat) {
				foreach($postcat as $cat) { ?>
						<a class="iq-cat-name" href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"> <?php echo esc_html($cat->name); ?></a> <?php
				}
				}

				$postcat1 = wp_get_post_terms(get_the_ID(), 'team-categories');
				if ($postcat1) {
				foreach($postcat1 as $cat1) {
					if(!empty($cat1->name)){ ?>
						<a class="iq-cat-name" href="<?php echo esc_url(get_category_link($cat1->term_id)); ?>"> <?php echo esc_html($cat1->name); ?></a> <?php
					}	
				}
				} ?>

			</div>

			<?php if(!is_single())
				{
				?>
				<div class="blog-title">
				
					<h3 class="entry-title">
						<a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
							<?php the_title(); ?>
						</a>
					</h3>						
				</div>
				<?php 
				}
				?>
				
				<div class="iq-blog-meta">
					<ul class="list-inline">
						<li class="list-inline-item">
								<a href="<?php echo  sprintf("%s",get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ),'kivicare'); ?>" class="iq-user">
								<i class="fa fa-user-o mr-1" aria-hidden="true"></i>
									<?php echo  sprintf("%s ",get_the_author(),'kivicare'); ?>
								</a>
							</li>
				
							<li class="list-inline-item">
								<i class="fa fa-calendar mr-1" aria-hidden="true"></i>
									<?php echo sprintf("%s",kivicare_time_link()); ?>
							</li>

					</ul>
				</div>
			

			<div class="blog-content">
				<?php 
					if(is_single()){
						the_content();
					}else{
						the_excerpt();
					}

					wp_link_pages( array(
						'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'kivicare' ),
						'after'       => '</div>',
						'link_before' => '<span class="page-number">',
						'link_after'  => '</span>',
					) );
					?>
			</div>


			<?php if(!is_single()){ ?>
				<div class="iq-btn-container">
						<a class="iq-button iq-btn-link yes btn-icon-right" href="<?php the_permalink(); ?>">   
							<?php echo esc_html__('Read More' , 'kivicare') ?>
							
							<i aria-hidden="true" class="ion ion-plus ml-2"></i>

						</a>
					</div>
			<?php
			}
			?>							
		</div>	
	</div>		
	<?php 
	$kivi_option = get_option('kivi_options');
	if(isset($kivi_option['kivi_display_comment']))
	{
		$options = $kivi_option['kivi_display_comment'];
		if($options == "yes")
		{
			if(is_single()){
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

				kivicare_pagination();
			}
		}
	}
	?>
</article><!-- #post-## -->
