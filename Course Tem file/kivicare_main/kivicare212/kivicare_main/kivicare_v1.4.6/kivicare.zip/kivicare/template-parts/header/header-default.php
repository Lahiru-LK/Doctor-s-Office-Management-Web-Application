<?php
/**
* Displays header widgets if assigned
*
* @package WordPress
* @subpackage kivicare
* @since 1.0
* @version 1.0
*/

$kivi_option = get_option('kivi_options');
$has_sticky = '';
if(isset($kivi_option['sticky_header_display']) && $kivi_option['sticky_header_display'] == 'yes')
{
  $has_sticky = ' has-sticky';
}
?>
<header class="style-one<?php echo esc_attr($has_sticky); ?>" id="main-header"> <?php

  if(isset($kivi_option['email_and_button'])) {
      $options = $kivi_option['email_and_button'];
      if($options == "yes") { ?>
        <div class="container-fluid sub-header">
          <div class="row align-items-center">

            <div class="col-auto"> <?php
              if(!empty($kivi_option['header_display_contact'])) {
                $options = $kivi_option['header_display_contact'];
                if($options == "yes") { ?>
                  <div class="number-info">
                    <ul class="list-inline">
                        <?php
                        if(!empty($kivi_option['header_email']))
                        {
                        ?>
                        <li class="list-inline-item"><a href="mailto:<?php echo esc_url($kivi_option['header_email']); ?>">
                        <i class="fa fa-envelope"></i><?php echo esc_html($kivi_option['header_email']); ?></a></li>
                        <?php } ?>
                        <?php if(!empty($kivi_option['header_phone']))
                        {
                        ?>
                        <li class="list-inline-item"><a href="tel:<?php echo str_replace(str_split('(),-" '), '',$kivi_option['header_phone']); ?>">
                        <i class="fa fa-phone"></i><?php echo esc_html($kivi_option['header_phone']); ?></a></li>
                        <?php } ?>
                    </ul>
                  </div> <?php
                }
              } ?>
            </div>

          </div>
        </div>
        <?php
        }
      } ?>
      <div class="container-fluid main-header">
        <div class="row align-items-center">
          <div class="col-sm-12">
            <nav class="navbar navbar-expand-xl navbar-light"> <?php
              if(isset($kivi_option['header_radio']) && $kivi_option['header_radio'] == 1) { ?>
                  <a href="<?php  echo esc_url( home_url( '/' ) ); ?>"> <?php
                    if(!empty($kivi_option['header_text'])) { ?>
                        <h1 class="logo-text"><?php echo esc_html($kivi_option['header_text']); ?></h1> <?php
                    } ?>
                  </a> <?php
              } else { ?>

                <a class="navbar-brand" href="<?php  echo esc_url( home_url( '/' ) ); ?>"> <?php
                    if(function_exists('get_field') && class_exists('ReduxFramework')) {
                        $key = get_field('key_header');
                        if(!empty($key['header_logo']['url']))
                        {
                          $logo = $key['header_logo']['url'];
                        }
                        else if(isset($kivi_option['kivi_logo']['url']))
                        {
                          $logo = $kivi_option['kivi_logo']['url'];
                        } ?>
                        <img class="img-fluid logo" src="<?php echo esc_url($logo); ?>" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php 
                    } else { ?>
                          <img class="img-fluid logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/logo.png" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php 
                    } ?> </a>
            <?php
            }
            ?>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon">
                      <span class="menu-btn d-inline-block" id="menu-btn">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                     </span>
              </span>
              </button>

                  <div class="collapse navbar-collapse" id="navbarSupportedContent"> <?php 
                      if ( has_nav_menu( 'top' ) ) : ?> <?php 
                          wp_nav_menu( array(
      												'theme_location' => 'top',
                              'menu_class'     => 'navbar-nav ml-auto',
                              'menu_id'        => 'top-menu',
                              'container_id'   => 'iq-menu-container',
    											) ); ?> <?php 
                      endif;

                      if((!empty($kivi_option['kivi_download_link'])) && (!empty($kivi_option['kivi_download_title']))) { ?>
                        <div class="iq-mobile-main">
                      
                            <nav aria-label="breadcrumb"> <?php 
                                $dlink = $kivi_option['kivi_download_link'];
                                $dtitle = $kivi_option['kivi_download_title']; ?>
                                <a class="iq-button-style-2 has-icon btn-icon-right mr-20" href="<?php echo esc_url(site_url(). $dlink ) ?>">  
                                  <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                </a> <?php
                                if((!empty($kivi_option['kivi_btn2_link'])) && (!empty($kivi_option['kivi_btn2_title']))) {
                                    $dlink = $kivi_option['kivi_btn2_link']; 
                                    $dtitle = $kivi_option['kivi_btn2_title']; ?>
                              
                                    <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo esc_url(site_url().$dlink); ?>">  
                                      <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                    </a> <?php 
                                } else {

                                  $dtitle = $kivi_option['kivi_btn2_title']; ?>
            
                                  <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo wp_login_url(); ?>">  
                                    <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                  </a> <?php
                                } ?>
                          </nav>
                        </div> <?php 
                      } 
                      ?>

                  </div>

            
            </nav>
          </div>
        </div>
      </div>
</header>
<div class="iq-height"></div>
