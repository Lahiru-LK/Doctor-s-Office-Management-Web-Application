<?php
/**
* Displays header widgets if assigned
*
* @package WordPress
* @subpackage kivicare
* @since 1.0
* @version 1.0
*/
$kivi_option = get_option('kivi_options');
$has_sticky = '';
if(isset($kivi_option['sticky_header_display']) && $kivi_option['sticky_header_display'] == 'yes')
{
  $has_sticky = ' has-sticky';
}

$kivi_container = '';
if(isset($kivi_option['header_menu_container']) && $kivi_option['header_menu_container'] == 'container' ) {
  $kivi_container = 'container';
} else {
  $kivi_container = 'container-fluid';
}

?>
<header class="style-one<?php echo esc_attr($has_sticky); ?>" id="main-header"> <?php

  if(isset($kivi_option['email_and_button'])) {
      $options = $kivi_option['email_and_button'];
      if($options == "yes") { ?>
        <div class="<?php echo esc_attr($kivi_container); ?> sub-header">
          <div class="row align-items-center">

            <div class="col-auto"> <?php
              if(!empty($kivi_option['header_display_contact'])) {
                $options = $kivi_option['header_display_contact'];
                if($options == "yes") { ?>
                  <div class="number-info">
                    <ul class="list-inline">
                        <?php
                        if(!empty($kivi_option['header_email']))
                        {
                        ?>
                        <li class="list-inline-item"><a href="mailto:<?php echo esc_html($kivi_option['header_email']); ?>">
                        <i class="fa fa-envelope"></i><?php echo esc_html($kivi_option['header_email']); ?></a></li>
                        <?php } ?>
                        <?php if(!empty($kivi_option['header_phone']))
                        {
                        ?>
                        <li class="list-inline-item"><a href="tel:<?php echo str_replace(str_split('(),-" '), '',$kivi_option['header_phone']); ?>">
                        <i class="fa fa-phone"></i><?php echo esc_html($kivi_option['header_phone']); ?></a></li>
                        <?php } ?>
                    </ul>
                  </div> <?php
                }
              } ?>
            </div>

            <div class="col-auto col-auto ml-auto sub-main">
              <?php
              $kivi_option = get_option('kivi_options');
              
              if(isset($kivi_option['kivi_header_social_media']))  
              {
                $options = $kivi_option['kivi_header_social_media'];
                if($options == "yes"){ ?>
                  <div class="social-icone">
                    <?php $data = $kivi_option['social-media-iq']; ?>
                    
                    <ul class="list-inline">
                      <?php
                      foreach ($data as $key=>$options )
                      {
                        if($options) {
                          echo '<li class="d-inline"><a href="'.esc_url($options).'"><i class="fa fa-'.esc_attr($key).'"></i></a></li>';
                        }
                      } ?>
                    </ul>
                  </div>
              <?php
                }
              }
              ?>
            </div>
          </div>
        </div>
        <?php
        }
      } ?>
      <div class="<?php echo esc_attr($kivi_container); ?> main-header">
        <div class="row align-items-center">
          <div class="col-sm-12">
            <nav class="navbar navbar-expand-xl navbar-light"> <?php
              if(isset($kivi_option['header_radio']) && $kivi_option['header_radio'] == 1) { ?>
                  <a href="<?php  echo esc_url( home_url( '/' ) ); ?>"> <?php
                    if(!empty($kivi_option['header_text'])) { ?>
                        <h1 class="logo-text"><?php echo esc_html($kivi_option['header_text']); ?></h1> <?php
                    } ?>
                  </a> <?php
              } else {
                
                $logo = ''; ?>

                <a class="navbar-brand" href="<?php  echo esc_url( home_url( '/' ) ); ?>"> <?php
                    if(function_exists('get_field') && class_exists('ReduxFramework')) {
                        $key = get_field('key_header');
                        if(!empty($key['header_logo']['url']))
                        {
                          $logo = $key['header_logo']['url']; ?>
                          <img class="img-fluid logo" src="<?php echo esc_url($logo); ?>" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php
                        }
                        else if(isset($kivi_option['kivi_logo']['url']) && !empty($kivi_option['kivi_logo']['url']))
                        {
                          $logo = $kivi_option['kivi_logo']['url']; ?>
                          <img class="img-fluid logo" src="<?php echo esc_url($logo); ?>" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php
                        } else { ?>
                          <img class="img-fluid logo" src="<?php echo esc_url(get_template_directory_uri() ); ?>/assets/images/logo.png" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php 
                        } ?>
                         <?php 
                    } else { ?>
                          <img class="img-fluid logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/logo.png" alt="<?php  esc_attr_e( 'kivicare', 'kivicare' ); ?>"> <?php 
                    } ?> </a>
            <?php
            }
            ?>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon">
                      <span class="menu-btn d-inline-block" id="menu-btn">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                     </span>
              </span>
              </button>

                  <div class="collapse navbar-collapse" id="navbarSupportedContent"> <?php 
                      if ( has_nav_menu( 'top' ) ) : ?> <?php 
                          wp_nav_menu( array(
                              'theme_location' => 'top',
                              'menu_class'     => 'navbar-nav ml-auto',
                              'menu_id'        => 'top-menu',
                              'container_id'   => 'iq-menu-container',
                          ) ); ?> <?php 
                      endif;

                      if((!empty($kivi_option['kivi_download_link'])) && (!empty($kivi_option['kivi_download_title']))) { ?>
                        <div class="iq-mobile-main">
                      
                            <nav aria-label="breadcrumb"> <?php 
                                $dlink = $kivi_option['kivi_download_link'];
                                $dtitle = $kivi_option['kivi_download_title']; ?>
                                <a class="iq-button-style-2 has-icon btn-icon-right mr-20" href="<?php echo esc_url(site_url(). $dlink ) ?>">  
                                  <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                </a> <?php
                                if((!empty($kivi_option['kivi_btn2_link'])) && (!empty($kivi_option['kivi_btn2_title']))) {
                                    $dlink = $kivi_option['kivi_btn2_link'];
                                    $dtitle = $kivi_option['kivi_btn2_title']; ?>
                              
                                    <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo esc_url(site_url().$dlink); ?>">  
                                      <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                    </a> <?php 
                                } else {

                                  $dtitle = $kivi_option['kivi_btn2_title']; ?>
            
                                  <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo wp_login_url(); ?>">  
                                    <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                                  </a> <?php
                                } ?>
                          </nav>
                        </div> <?php 
                      } 
                      ?>

                  </div>

              <div class="sub-main">
                
                  <nav aria-label="breadcrumb"> <?php 
                  
                    if((!empty($kivi_option['kivi_download_link'])) && (!empty($kivi_option['kivi_download_title']))) {
                        $dlink = $kivi_option['kivi_download_link'];
                        $dtitle = $kivi_option['kivi_download_title']; ?>
                  
           <a class="iq-button-style-2 has-icon btn-icon-right mr-3" href="<?php echo esc_url(site_url(). $dlink ) ?>">  
                          <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                        </a> <?php 
                    }
            
                    if((!empty($kivi_option['kivi_btn2_link'])) && (!empty($kivi_option['kivi_btn2_title']))) {
                        $dlink = $kivi_option['kivi_btn2_link'];
                        $dtitle = $kivi_option['kivi_btn2_title']; ?>
                  
                        <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo esc_url(site_url().$dlink); ?>">  
                          <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                        </a> <?php 
                    } else {

                        if(isset($kivi_option['kivi_btn2_title'])) {

                            $dtitle = $kivi_option['kivi_btn2_title']; ?>

                        <a class="iq-button-style-1 has-icon btn-icon-right" href="<?php echo wp_login_url(); ?>">  
                          <span class="iq-btn-text-holder"><?php echo esc_html($dtitle); ?></span><span class="iq-btn-icon-holder"><i aria-hidden="true" class="ion ion-plus"></i></span>
                        </a> <?php
                        }

                    } ?>
                    <!-- shop page button start -->
                    <!--mobile View-->
                    <?php
                    if ( class_exists( 'WooCommerce' ) && isset($kivi_option['header_display_shop']) && $kivi_option['header_display_shop'] == 'yes') 
                    {   
                      ?>
                    <div class="woo-menu">
                    <div id="shop-toggle">
                    <div class="kivi-res-shop-btn-container" id='x-ver-res-btn'>
                        <?php 
                          $shop_url = '';
                          if(isset($kivi_option['shop_link']) && !empty($kivi_option['shop_link']))
                          {
                            $shop_url = get_page_link($kivi_option['shop_link']);
                          }
                       ?>
                        <a href="<?php echo esc_url($shop_url); ?>">
                          <span class="kivi-res-shop-btn">
                              <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                          </span>
                        </a>
                    </div>
                    <ul class="shop_list">
                    <!-- wishlist -->
                            <?php 
                        if(function_exists('YITH_WCWL') && isset($kivi_option['header_display_shop']) && $kivi_option['header_display_shop'] == 'yes')
                        {
                          $wish_url = '';
                          if(isset($kivi_option['wishlist_link']) && !empty($kivi_option['wishlist_link']))
                          {
                            $wish_url = get_page_link($kivi_option['wishlist_link']);
                          }
                       ?>
                         <li class="wishlist-btn kivi-shop-btn">
                            <div class="wishlist_count">
                              <?php $wishlist_count = YITH_WCWL()->count_products(); ?>
                              <a href="<?php echo esc_url($wish_url); ?>">
                                <i class="fa fa-heart"></i>
                                <span class="wcount"><?php echo esc_html($wishlist_count); ?></span>
                              </a>
                            </div>
                         </li>
                      <?php } ?>
                      <!-- mini cart -->
                      <?php 
                      if(isset($kivi_option['header_display_shop']))
                      {
                        $options = $kivi_option['header_display_shop'];
                        if($options == "yes")
                        { ?>
                      <li class="cart-btn kivi-shop-btn">
                        <div class="cart_count">
                          <a class="parents mini-cart-count" href="<?php echo wc_get_cart_url(); ?>">
                              <i class="fa fa-shopping-cart"></i>
                              <span id="mini-cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                          </a>
                        </div>
                      </li>  

                      <?php 
                        } 
                      }
                    ?>
                  </ul>
                </div>
              </div>
            <?php } ?>
                    <!-- shop page button end-->
                    <!-- side area btn container start-->
                    <?php 
                      if(isset($kivi_option['header_display_side_area']) && $kivi_option['header_display_side_area'] == 'yes')
                      {
                    ?>
                      <div class="iq-sidearea-btn-container" id="menu-btn-side-open">
                         <span class="menu-btn d-inline-block">
                             <span class="line one"></span>
                             <span class="line two"></span>
                             <span class="line three"></span>
                         </span>
                      </div>
                      <?php } ?>
                    <!-- side area btn container end-->
                  </nav>
                  
              </div>
            </nav>
          </div>
        </div>
      </div>
</header>
<div class="iq-height"></div>
