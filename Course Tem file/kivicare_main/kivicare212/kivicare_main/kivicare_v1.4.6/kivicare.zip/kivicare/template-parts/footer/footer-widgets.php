<?php
/**
* Displays footer widgets if assigned
*
* @package WordPress
* @subpackage kivicare
* @since 1.0
* @version 1.0
*/
?>
<?php
if( function_exists('get_field') && class_exists( 'ReduxFramework' ) ) {
   
    $kivi_option = get_option('kivi_options');
    
    if ( is_active_sidebar( 'footer_1_sidebar' ) ||
    is_active_sidebar( 'footer_2_sidebar' )  ||
    is_active_sidebar( 'footer_3_sidebar' )  ||
    is_active_sidebar( 'footer_4_sidebar' )  ||
    is_active_sidebar( 'footer_5_sidebar' )  ) :
    ?>
    <!-- Address -->
    <div class="footer-top">
        <div class="row">
            <?php

                $options = '';

                if(isset($kivi_option['kivi_footer_width'])) {
                    $options = $kivi_option['kivi_footer_width'];
                }
                
                
               
                   
                    $acf_key = get_field('acf_key_footer');
                    if($acf_key == "1")
                    {
                        if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_1_sidebar' ) ) 
                        { 
                        ?>
                            <div class="col-lg-12 col-md-6 col-sm-6 ">
                                <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                            </div>
                        <?php  
                        }
                    }
                    else if($acf_key == "2")
                    {
                        if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                            <div class="col-lg-6 col-md-6 col-sm-6 ">
                                <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                            </div>
                        <?php }
                    }
                    else if($acf_key == "3")
                    {
                        if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                                <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                            </div>
                        <?php }
                        if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 mt-lg-0 mt-md-5 mt-4">
                                <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                            </div>
                        <?php }
                    }
                   else if($acf_key == "4")
                    {
                       if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                       if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_4_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_4_sidebar' ); ?>
                        </div>
                    <?php } 
                    }
                    else if($acf_key == "5")
                    {
                        if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                        if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                         <div class="col-lg-3 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_4_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_4_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_5_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_5_sidebar' ); ?>
                        </div>
                    <?php }
                     
                    }
                

                else if($options == 1)
                {
                    if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-12 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php  }
                }

                else if($options == 2)
                {
                    if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php }
                }

                else if($options == 3)
                {
                    
                    if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 mt-lg-0 mt-md-5 mt-4">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                }

                else if($options == 4)
                { 
                    if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_4_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_4_sidebar' ); ?>
                        </div>
                    <?php }
                }

                else if($options == 5)
                { 
                    if( is_active_sidebar( 'footer_6_sidebar' ) ) { ?>
                         <div class="col-lg-12 col-md-12 col-sm-12 footer_top_block">
                        <?php dynamic_sidebar( 'footer_6_sidebar' ); ?>
                         </div>
                        <?php   }
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                         <div class="col-lg-3 col-md-12 col-sm-12">
                        <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                         </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-4 mt-lg-0 mt-md-0">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_4_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_4_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_5_sidebar' ) ) { ?>
                        <div class="col-lg-2 col-md-6 col-sm-6 mt-lg-0 mt-4">
                            <?php dynamic_sidebar( 'footer_5_sidebar' ); ?>
                        </div>
                    <?php }
                     
                }

                if(empty($options))
                {
                    if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                        </div>
                    <?php   }
                    if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                        </div>
                    <?php }
                    if( is_active_sidebar( 'footer_4_sidebar' ) ) { ?>
                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                            <?php dynamic_sidebar( 'footer_4_sidebar' ); ?>
                        </div>
                    <?php }
                }
            ?>
        </div>
    </div>
    <?php endif; 
}
else
{ 
if ( is_active_sidebar( 'footer_1_sidebar' ) ||
is_active_sidebar( 'footer_2_sidebar' )  ||
is_active_sidebar( 'footer_3_sidebar' )  ||
is_active_sidebar( 'footer_4_sidebar' )  ) :
?>
<!-- Address -->
<div class="footer-top">
    <div class="row">

                <?php
                if( is_active_sidebar( 'footer_1_sidebar' ) ) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 ">
                        <?php dynamic_sidebar( 'footer_1_sidebar' ); ?>
                    </div>
                <?php   }
                if( is_active_sidebar( 'footer_2_sidebar' ) ) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 ">
                        <?php dynamic_sidebar( 'footer_2_sidebar' ); ?>
                    </div>
                <?php }
                if( is_active_sidebar( 'footer_3_sidebar' ) ) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 ">
                        <?php dynamic_sidebar( 'footer_3_sidebar' ); ?>
                    </div>
                <?php } ?>
            
    </div>
</div>
<?php endif;
}
?>
<!-- Address END -->
