<?php
/**
 * Displays footer site info
 *
 * @package WordPress
 * @subpackage kivicare
 * @since 1.0
 * @version 1.0
 */

?>
<?php $kivi_option = get_option('kivi_options'); ?>
<div class="copyright-footer">
	<div class="pt-3 pb-3">
		<div class="row flex-row-reverse justify-content-between">
			<?php
			if(isset($kivi_option['display_copyright']))
			{
			$options = $kivi_option['display_copyright'];
			if($options == "yes")
			{ 
				$options= $kivi_option['footer_copyright_align'];
				$footer_copyright_align ='';
				if($options == "1"){ $footer_copyright_align = 'text-lg-left'; } 
				if($options == "3"){ $footer_copyright_align = 'text-lg-center'; }
			?>
			<div class="col-lg-12 col-md-12 <?php echo esc_attr($footer_copyright_align); ?> text-md-center text-center">
				<?php
				if(isset($kivi_option['footer_copyright'])) {  ?>
					<span class="copyright"><?php echo html_entity_decode($kivi_option['footer_copyright']); ?></span>
					<?php
				}
				else {	?>
					<span class="copyright"><a target="_blank" href="<?php echo esc_url( __( 'https://themeforest.net/user/iqonicthemes/portfolio/', 'kivicare' ) ); ?>"> <?php printf( esc_html__( 'Proudly powered by Kivicare', 'kivicare' ), 'kivicare.' ); ?></a></span>
					<?php
				} ?>
			</div>
			<?php
			}
			}
			else { 
			?>
			<div class="col-lg-12 col-md-12 text-center">
				<?php
				if(isset($kivi_option['footer_copyright'])) { ?>
					<span class="copyright"><?php echo html_entity_decode($kivi_option['footer_copyright']); ?></span>
					<?php
				}
				else {	?>
					<span class="copyright"><a target="_blank" href="<?php echo esc_url( __( 'https://themeforest.net/user/iqonicthemes/portfolio/', 'kivicare' ) ); ?>"> <?php printf( esc_html__( 'Proudly powered by Kivicare', 'kivicare' ), 'kivicare.' ); ?></a></span>
					<?php
				} ?>
			</div>
			<?php
			}
			?>
		</div>
	</div>
</div>
