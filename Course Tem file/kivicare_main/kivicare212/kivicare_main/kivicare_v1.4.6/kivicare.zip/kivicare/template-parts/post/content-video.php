<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	$content = apply_filters( 'kivicare_the_content', get_the_content() );
	$video = false;

	// Only get video from the content if a playlist isn't present.
	if ( false === strpos( $content, 'wp-playlist-script' ) ) {
		$video = get_media_embedded_in_content( $content, array( 'video', 'object', 'embed', 'iframe' ) );
	}
	?>
	<div class="iq-blog-box">	
		<?php
		$kivi_option = get_option('kivi_options');
		if(isset($kivi_option['kivi_display_image']))
		{
		$options = $kivi_option['kivi_display_image'];
		if($options == "yes"){
			if ( has_post_thumbnail() ) { ?>
			<div class="iq-blog-image">
				<?php
					the_content();

					wp_link_pages( array(
						'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'kivicare' ),
						'after'       => '</div>',
						'link_before' => '<span class="page-number">',
						'link_after'  => '</span>',
					) );
				
				?>
			</div>	
			<?php } 
		} 
		}
		else 
		{
		?>
			<div class="iq-blog-image">
				<?php
				the_content();

				wp_link_pages( array(
					'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'kivicare' ),
					'after'       => '</div>',
					'link_before' => '<span class="page-number">',
					'link_after'  => '</span>',
				) );
				?>
			</div>	
		<?php
		}
		?>
		<div class="iq-blog-detail">
				<div class="iq-blog-meta">
					<ul class="list-inline">
						<li class="list-inline-item">
							<?php echo kivicare_time_link(); ?>
						</li>
					</ul>
				</div>
				<?php if(!is_single())
				{
				?>
				<div class="blog-title">
				
					<h3 class="entry-title">
						<a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
							<?php the_title(); ?>
						</a>
					</h3>
				</div>
				<?php 
				}
				?>

			
			<?php if(!is_single()){ ?>
				<div class="iq-btn-container">
						<a class="iq-button iq-btn-link yes btn-icon-right" href="<?php the_permalink(); ?>">   
							<?php echo esc_html__('Read More' , 'kivicare') ?>
							
							<i aria-hidden="true" class="ion ion-plus ml-2"></i>

						</a>
					</div>
			<?php
			}
			?>							
		</div>	
	</div>	
			
	<?php 
	$kivi_option = get_option('kivi_options');
	if(isset($kivi_option['kivi_display_comment']))
	{
		$options = $kivi_option['kivi_display_comment'];
		if($options == "yes")
		{
			if(is_single()){
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

				kivicare_pagination();
			}
		}
	}
	else {
		if(is_single()){
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

			kivicare_pagination();
		}
		
	}

	?>
</article><!-- #post-## -->
