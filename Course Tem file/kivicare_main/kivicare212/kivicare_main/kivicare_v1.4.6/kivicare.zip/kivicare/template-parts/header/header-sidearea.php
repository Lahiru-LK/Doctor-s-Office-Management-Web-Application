<!-- side area btn container start-->
  <div class="iq-sidearea-btn-container btn-container-close" id="menu-btn-side-close">
     <span class="menu-btn d-inline-block is-active">
         <span class="line"></span>
         <span class="line"></span>
         <span class="line"></span>
     </span>
  </div>
  <!-- side area btn container end-->
<div id="sidebar-scrollbar">
<div class="iq-sidebar-container">
 	<div class="iq-sidebar-content">
 		<?php 
		 if( is_active_sidebar( 'kivi_side_area' ) )
		 {
		 	dynamic_sidebar( 'kivi_side_area' );
		 }
	 ?>	
 	</div>	 
</div>
</div>
