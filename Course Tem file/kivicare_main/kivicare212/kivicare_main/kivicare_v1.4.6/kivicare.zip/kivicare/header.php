<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage kivicare
 * @since 1.0
 * @version 1.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">

<head>
<!-- Required meta tags -->
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <?php
    $kivi_option = get_option('kivi_options');
      ?>
  
    <?php
    if ( ! function_exists( 'has_site_icon' ) || ! wp_site_icon() ) {
          if( !empty($kivi_option['kivi_fevicon']) ) { ?>
            <link rel="shortcut icon" href="<?php echo esc_url($kivi_option['kivi_fevicon']['url']); ?>" />
            <?php 
          }
          else{
            ?>
            <link rel="shortcut icon" href="<?php echo esc_url(get_template_directory_uri().'/assets/images/favicon.ico'); ?>" />
          <?php }
        }
    ?>
    
<?php wp_head(); ?>
</head>

<?php
  if(function_exists('get_field') && class_exists('ReduxFramework'))
  {
    $page_id_for_body = get_queried_object_id();
    $key_for_body_back = get_field('key_body' , $page_id_for_body);

    if(isset($key_for_body_back['body_variation']) && $key_for_body_back['body_variation'] == 'has_body_image')
    {
      $bglayout = $key_for_body_back['acf_body_image']['url'];
    }
    else if(!empty($kivi_option['kivi_layout_image']['url']) && isset($kivi_option['kivi_layout_image']['url']) && $key_for_body_back['body_variation'] == 'default'){
        $bglayout = $kivi_option['kivi_layout_image']['url'];
    }
    else
    {
     $bglayout = ''; 
    }
  }

if(class_exists('ReduxFramework')) {

    $kivi_option = get_option('kivi_options');


    if(!empty($kivi_option['kivi_layout_image']['url']) && isset($kivi_option['kivi_layout_image']['url']) && $key_for_body_back['body_variation'] != 'default'){
        $bglayout = $kivi_option['kivi_layout_image']['url'];
    } else {
     $bglayout = ''; 
    }
  }
?>


<body data-spy="scroll" data-offset="80" <?php body_class(); ?> <?php


$kivi_option = get_option('kivi_options');


if( !empty($kivi_option['layout_set']) && $kivi_option['layout_set'] == "3" ) { ?>
    style="background: url(<?php if(!empty($bglayout)){ echo esc_url($bglayout); } ?>)" <?php
} ?> >

<?php wp_body_open(); ?>
<!-- side area start-->
<?php 
if(class_exists('ReduxFramework'))
{
?>
<div id="has-side-bar" class="iq-menu-side-bar">
  <?php 
    get_template_part( 'template-parts/header/header', 'sidearea' );
  ?>
</div>
<?php } ?>
<!-- side area end-->
<?php
if(!empty($kivi_option['kivi_display_loader'])) {
    $options = $kivi_option['kivi_display_loader'];
}    

  if(!empty($options) && $options == "yes" && class_exists( 'ReduxFramework' ))
  {
  ?>
  <!-- loading -->
  <div id="loading">
    <div id="loading-center">
        <?php
          if(!empty($kivi_option['kivi_loader_gif']['url'])){
          $bgurl = $kivi_option['kivi_loader_gif']['url'];
          ?>
          <img src="<?php echo esc_url($bgurl); ?>" alt="<?php esc_attr_e('loader','kivicare'); ?>">
          <?php
          }
        ?>        
    </div>
  </div>
  <!-- loading End -->
  <?php
  }
?>
<div id="page" class="site">
  
  <a class="skip-link screen-reader-text" href="#content"><?php esc_html__( 'Skip to content', 'kivicare' ); ?></a>
    <?php

    if(!empty($kivi_option['kivi_header_variation'])) {
        $head_style = $kivi_option['kivi_header_variation'];
    }    
    
    if(function_exists('get_field') && class_exists('ReduxFramework'))
    {
      $page_id = get_queried_object_id();
      $key = get_field('key_header' , $page_id);
      
      if(isset($key['header_variation']) && $key['header_variation'] != "default")
      {
        if($key['header_variation'] == "1")
        {
          get_template_part( 'template-parts/header/header', 'one' );
        }
      } else if(!empty($head_style) && $head_style == "1") {
        get_template_part( 'template-parts/header/header', 'one' );
      } else {
        get_template_part( 'template-parts/header/header', 'one' );
      }
      
    }
   
    else
    {
      get_template_part( 'template-parts/header/header', 'default' );
    }
    ?>
  <?php kivicare_display_header(); ?>
  <div class="site-content-contain">
    <div id="content" class="site-content">
