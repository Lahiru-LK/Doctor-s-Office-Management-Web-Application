<?php
/**
 * Template part for displaying a pagination
 *
 * @package kivicare
 */

namespace Kivicare\Utility;

kivicare()->kivicare_pagination();
