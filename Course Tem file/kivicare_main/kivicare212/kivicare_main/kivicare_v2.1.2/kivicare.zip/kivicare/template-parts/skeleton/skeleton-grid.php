<div class="kivicare-sub-product product type-product skeleton-main skeleton-grid column-2">

    <div class="kivicare-inner-box">
        <a href="#"></a>
        <div class="skeleton skt-img">
        </div>
        <div class="skeleton-box">
            <span class="skeleton skt-title mb-4"></span>
            <span class="skeleton skt-price mb-4"></span>
            <span class="skeleton skt-rating"></span>
        </div>
    </div>
</div>
<div class="kivicare-sub-product product type-product skeleton-main skeleton-grid column-3">

    <div class="kivicare-inner-box">
        <a href="#"></a>
        <div class="skeleton skt-img">
        </div>
        <div class="skeleton-box">
            <span class="skeleton skt-title mb-4"></span>
            <span class="skeleton skt-price mb-4"></span>
            <span class="skeleton skt-rating"></span>
        </div>
    </div>
</div>
<div class="kivicare-sub-product product type-product skeleton-main skeleton-grid column-4">
    <div class="kivicare-inner-box">
    <a href="#"></a>
        <div class="skeleton skt-img">
        </div>
        <div class="skeleton-box">
            <span class="skeleton skt-title mb-4"></span>
            <span class="skeleton skt-price mb-4"></span>
            <span class="skeleton skt-rating"></span>
        </div>
    </div>
</div>