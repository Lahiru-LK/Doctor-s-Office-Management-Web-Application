<?php

/**
 * Kivicare\Utility\Dynamic_Style\Styles\General class
 *
 * @package kivicare
 */

namespace Kivicare\Utility\Dynamic_Style\Styles;

use Kivicare\Utility\Dynamic_Style\Component;
use function add_action;

class General extends Component
{
	public function __construct()
	{

		add_action('wp_enqueue_scripts', array($this, 'kivicare_create_general_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'kivicare_page_404'), 20);
	}

	public function kivicare_create_general_style()
	{
		global $kivicare_options;
		$general_var = '';

		if (isset($kivicare_options['opt-slider-label']) && !empty($kivicare_options['opt-slider-label']['width'])) {

			$container_width = $kivicare_options['opt-slider-label']['width'];
			if ($container_width !== 'px' && $container_width !== 'em' && $container_width !== '%') {
				$general_var = "
					body.iq-container-width .container,
					body .elementor-section.elementor-section-boxed>.elementor-container {
						max-width: " . $container_width . ";
					} ";
			}
		}

		if ($kivicare_options['layout_set'] == 1) {
			if (isset($kivicare_options['kivi_layout_color'])  && !empty($kivicare_options['kivi_layout_color'])) {
				$general = $kivicare_options['kivi_layout_color'];
				$general_var .= 'body { background : ' . $general . ' !important; }';
			}
		}
		if ($kivicare_options['layout_set'] == 3) {
			if (isset($kivicare_options['kivi_layout_image']['url']) && !empty($kivicare_options['kivi_layout_image']['url'])) {
				$general = $kivicare_options['kivi_layout_image']['url'];
				$general_var .= 'body { background-image: url(' . $general . ') !important; }';
			}
		}

		if ($kivicare_options['kivi_back_to_top'] == 'no') {
			if (isset($kivicare_options['kivi_back_to_top']) && !empty($kivicare_options['kivi_back_to_top'])) {
				$general_var .= '#back-to-top { display: none !important; }';
			}
		}
		
		if (!empty($general_var)) {
			wp_add_inline_style('kivicare-global', $general_var);
		}
	}
	/* 404 Page Options */
	public function kivicare_page_404()
	{
		if (is_404()) {
			global $kivicare_options;

			$header_footer_css = '';

			if (!$kivicare_options['header_on_404']) {
				$header_footer_css .= 'header#default-header { 
				display : none !important;
			}';
			}
			if (!$kivicare_options['footer_on_404']) {
				$header_footer_css .= 'footer { 
				display : none !important;
			}';
			}
			if (!empty($header_footer_css)) {
				wp_add_inline_style('kivicare-global', $header_footer_css);
			}
		}
	}
}
